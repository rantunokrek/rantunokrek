
@extends('layouts.frontendview.app')
@section('title')
{{$post->title}}
@endsection
@push('css')	


   
   

    <link  rel="stylesheet" href="{{asset('assets/frontend/css/single-post/css/fontawesome.css')}}" />
    <link  rel="stylesheet" href="{{asset('assets/frontend/css/single-post/css/templatemo-stand-blog.css')}}" />
    <link  rel="stylesheet" href="{{asset('assets/frontend/css/single-post/css/owl.css')}}" />
   
  <style>
    .single-bg{
      height:400px;
      width:100%;
      background-size:cover;
      background-image: url({{ Storage::disk('public')->url('post/'.$post->image)}});
     
    }
    .favorite_posts{
		color:blue;
	}
  </style>

@endpush
@section('m-content')
<div class="single-post">
		<div class="container">
			<div class="row">
				<div class="col-lg-12 col-md-12 col-sm-12">
					<div class="single-bg">
					
					</div>
				</div> <!-- col-lg-12 -->
			</div> <!-- row -->
		</div> <!-- container -->
	</div> <!-- slider-area -->
<section class="blog-posts grid-system">
      <div class="container">
        <div class="row">
          <div class="col-lg-8">
            <div class="all-blog-posts">
              <div class="row">
                <div class="col-lg-12">
                  <div class="blog-post">
                    <!-- <div class="blog-thumb"> -->
                      <!-- <img src="assets/images/blog-post-02.jpg" alt=""> -->
                    <!-- </div> -->
                    <div class="down-content">
          
                      <h4>{{ $post->title }}</h4>
                      <ul class="post-info">
                        <img style="width:30px;height:30px" src="{{ 
                          Storage::disk('public')->url('profile/'.$post->user->image)
                        }}" alt="">
                        <li><a href="#">{{ $post->user->name }}</a></li>
                        <li><a href="#">{{ $post->created_at->diffForHumans() }}</a></li>
                       
                      </ul>
                      <p>
                        {!! html_entity_decode($post->body) !!}

                      </p>
                      <div class="post-options">
                        <div class="row">
                          <div class="col-6">
                            <ul class="post-tags">
                            <div class="comment-section">
                                <li class="comment-btn"> 
                                @guest 
                                
                                <a href="javascript:void(0);" onclick="toastr.info('To add favorite list. You need to login first.','Info',
                                {
                                  closeButton:true,
                                  progressBar: true,
                                  
                                })"><i class="fas fa-heart"> </i>  {{ $post->favorite_to_users->count() }}</a> 
                                </li>
                                @else
                                
                                <a href="javascript:void(0);" onclick="document.getElementById('favorite-form-{{ $post->id }}').submit();" 
                                class="{{ !Auth::user()->favorite_posts->where('pivot.post_id',$post->id)->count() == 0 ? 'favorite_posts' : '' }}">
                                <i class="fas fa-heart "> </i>  
                                {{ $post->favorite_to_users->count() }}</a>
                                <form id="favorite-form-{{ $post->id }}" action="{{ route('post.favorite',$post->id )}}" method="POST" style="display: none;">
                                  @csrf
                                </form>
                              
                                
                                @endguest
                               

                              
                                <li class="comment-btn"> <a href=""> <i class="fas fa-comment"></i> </a> 27 </li>
                                <li class="comment-btn"> <a href=""><i class="fas fa-eye"></i> {{ $post->view_count }} </a>  </li>
								            </div>
                            </ul>

                          



                          </div>
                          <div class="col-6">
                            <ul class="post-share">
                              <li><i class="fa fa-share-alt"></i></li>
                              <li><a href="#">Facebook</a>,</li>
                              <li><a href="#"> Twitter</a></li>
                            </ul>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
               
               
              </div>
            </div>
            <!-- comments area -->
            <div class="col-lg-12">
                  <div class="sidebar-item submit-comment">
                    <div class="sidebar-heading">
                      <h2> Post comment</h2>
                    </div>
                    <div class="content">

                                @guest
                                <p>For post new comment You need to login first 
                                <a href="{{ route('login')}}">Login</a>
                                </p>
                                @else 
                               
                            
                                
                      <form id="comment" action="{{ route('comment.store',$post->id)}}" method="POST">
                        @csrf
                        <div class="row">
                       
                    
                          <div class="col-lg-12">
                            <fieldset>
                              <textarea name="comment" rows="6" id="message" placeholder="Type your comment" required=""></textarea>
                            </fieldset>
                          </div>
                          <div class="col-lg-12">
                            <fieldset>
                              <button type="submit" id="form-submit" class="main-button">Submit</button>
                            </fieldset>
                          </div>

                        </div>
                      </form>
                      @endguest

                    </div>
                  </div>
             </div>
 <!-- comments area end-->

              <div class="col-lg-12">
                  <div class="sidebar-item comments">
                    <div class="sidebar-heading">
                      <h2>Comments({{ $post->comments()->count()}})</h2>
                    </div>
                    
                   @if($post->comments()->count() > 0)
                   @foreach($post->comments as $comment)
                    <div class="content">
                 
                     
                       
                      <fieldset>

                            <ul class="post-info">
                              <img style="width:30px;height:30px" src="{{ 
                                Storage::disk('public')->url('profile/'.$comment->user->image)
                              }}" alt="">
                  
                              <li><a href="#">{{ $comment->created_at->diffForHumans() }}</a></li>
                            
                            </ul>
                            <p>
                            {{ $comment->comment }}

                            </p>
                      </fieldset>
                    
                    
                    </div>
                   
                    @endforeach
                    @else

                     There is no comment !
                   @endif
                  </div>
                 </div> <!--col-lg-12 -->
        
          </div>  <!-- end 8 col aerea -->
       <!-- ==right side bar here =======-->
          <div class="col-lg-4">
            <div class="sidebar">
              <div class="row">
                <div class="col-lg-12">
                   <div class="sidebar-heading">
                      <h2>About admin</h2>
                      <p>
                        {{ $post->user->about }}
                      </p>
                    </div>
                  
                </div>
                <div class="col-lg-12">
                  <div class="sidebar-item recent-posts">
                   
                    <div class="sidebar-heading">
                      <h2>Recent Posts</h2>
                    </div>
                    <div class="content">
                      <ul>
                        <li><a href="post-details.html">
                          <h5>Vestibulum id turpis porttitor sapien facilisis scelerisque</h5>
                          <span>May 31, 2020</span>
                        </a></li>
                        
                      </ul>
                    </div>
                  </div>
                </div>
                <div class="col-lg-12">
                  <div class="sidebar-item categories">
                    <div class="sidebar-heading">
                      <h2>Categories</h2>
                    </div>
                    <div class="content">
                      <ul>
                      @foreach($post->categories as $category)
                        <li><a href="{{route('category.posts',$category->slug)}}">{{ $category->name }}</a></li>
                       @endforeach
                      </ul>
                    </div>
                  </div>
                </div>
                <div class="col-lg-12">
                  <div class="sidebar-item tags">
                    <div class="sidebar-heading">
                      <h2>Tag Clouds</h2>
                    </div>
                    <div class="content">
                      <ul>
                        @foreach($post->tags as $tag)
                        <li><a href="#">{{ $tag->name }}</a></li>
                       @endforeach
                      </ul>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
         
        </div>
        <hr>
      </div>

      <div class="randoms">
                  <div class="ran-title ctr">
                      <h3>Relative posts</h3>
                
                    </div>
                  <div class="row">
                  
                            @foreach($randomposts as $randompost)
                              <div class="col-lg-4 col-md-6 col-sm-12">
                                <div class="block-202-single mb-40">
                                  <div class="block-202-img mb-20">
                                    <a href="{{route('post.details', $randompost->slug)}}">
                                    <img src="{{ Storage::disk('public')->url('post/'.$randompost->image)}}" alt="{{$randompost->name}}" />
                                    </a>
                                
                                    <div class="icon-202">
                                    <img id="i-fa"  src="{{ 
                            Storage::disk('public')->url('profile/'.$post->user->image)
                          }}" alt="">
                                    </div>
                                  </div>
                                  <div class="text-202 mb-20">
                                    <h2> <a href="{{route('post.details', $randompost->slug)}}">{{ str_limit($randompost->title,'15') }} </a> </h2>
                                    <p>{{ str_limit($randompost->body,'25') }}</p>
                                      <div class="comment-section">
                                        <li class="comment-btn"> 
                                        @guest 
                                        <a href="javascript:void(0);" onclick="toastr.info('To add favorite list. You need to login first.','Info',
                                        {
                                          closeButton:true,
                                          progressBar: true,
                                          
                                        })"><i class="fas fa-heart"> </i>  {{ $randompost->favorite_to_users->count() }}</a> 
                                        </li>
                                        @else
                                        
                                        <a href="javascript:void(0);" onclick="document.getElementById('favorite-form-{{ $randompost->id }}').submit();" 
                                        class="{{ !Auth::user()->favorite_posts->where('pivot.post_id',$randompost->id)->count() == 0 ? 'favorite_posts' : '' }}">
                                        <i class="fas fa-heart "> </i>  
                                        {{ $randompost->favorite_to_users->count() }}</a>
                                        <form id="favorite-form-{{ $randompost->id }}" action="{{ route('post.favorite',$post->id )}}" method="POST" style="display: none;">
                                          @csrf
                                        </form>
                                      
                                        
                                        @endguest

                                      
                                        <li class="comment-btn"> <a href=""> <i class="fas fa-comment"></i> </a> 27 </li>
                                        <li class="comment-btn"> <a href=""><i class="fas fa-eye"></i> {{ $randompost->view_count }} </a>  </li>
                                      </div>
                                </div>
                                
                                </div>
                              </div> <!-- col-lg-4 -->
                            @endforeach

                        </div> <!-- row -->
               </div>





               
    </section>

               

    @endsection
  


 

@push('js')	
   <!-- Bootstrap core JavaScript -->
   <script src="vendor/jquery/jquery.min.js"></script>
    <script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>


    <!-- Additional Scripts -->
    <script src="assets/js/custom.js"></script>
    <script src="assets/js/owl.js"></script>
    <script src="assets/js/slick.js"></script>
    <script src="assets/js/isotope.js"></script>
    <script src="assets/js/accordions.js"></script>

@endpush



  </body>

</html>
