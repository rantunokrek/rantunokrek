
@extends('layouts.frontendview.app')
@section('title')
@push('css')	
<style>
	.favorite_posts{
		color:red;
	}
</style>
@endpush
@section('m-content')
<div class="slider-area">
	<div class="container">
		<div class="row">
			<div class="col-lg-12 col-md-12 col-sm-12">
				<div class="slider-text">
					<h1 class="slider-h1">fontawesome is the best</h1>
					<span class="slider-span">like and share my font awesome font all it</span>
					<button class="btn-1">View more</button>
				</div>
			</div> <!-- col-lg-12 -->
		</div> <!-- row -->
	</div> <!-- container -->
</div> <!-- slider-area -->
<div class="slider-category">
		<div class="container">
			<div class="row">
				<div class="col-lg-12 col-md-12 col-sm-12">
					<div class="owl-carousel">
							@foreach($categories as $category)
							<div class="item">
								
							<a href="{{route('category.posts', $category->slug )}}">
							<img src="{{ Storage::disk('public')->url('category/slider/'.$category->image)}}" alt="{{$category->name}}" />
							</a>
							<a href="{{route('category.posts', $category->slug )}}"><h2>{{$category->name}}</h2></a>
							</div>
							@endforeach
						
				</div>
				</div> <!-- col-lg-12 -->
			</div> <!-- row -->
		</div> <!-- container -->
	</div> <!-- slider-area -->

    <!-- ======== block-202 ========= -->
<section class="block-202 wh-100 ptb-60">
	<div class="container">
		<div class="row">
			<div class="col-lg-12 col-md-12 col-sm-12">
				<div class="block-101-single mb-60 ctr">
				<h1>AWESOME FIRST CHOICE FONT</h1>
				<span class="slider-span">like and share my font awesome font all it</span>
				</div>
			</div> <!-- col-lg-12 -->
		</div> <!-- row -->
	
		<div class="row">
			@foreach($posts as $post)
				<div class="col-lg-4 col-md-6 col-sm-12">
					<div class="block-202-single mb-40">
						<div class="block-202-img mb-20">
							<a href="{{route('post.details', $post->slug)}}">
							<img src="{{ Storage::disk('public')->url('post/'.$post->image)}}" alt="{{$post->name}}" />
							</a>
					
							<div class="icon-202">
							<a href="{{ route('user.profile', $post->user->UserName)}}">
							<img id="i-fa"  src="{{ 
                          Storage::disk('public')->url('profile/'.$post->user->image)
                        }}" alt="">
							</a>
							</div>
						</div>
						<div class="text-202 mb-20">
							<h2> <a href="{{route('post.details', $post->slug)}}">{{ str_limit($post->title, '15') }} </a> </h2>
							<p> {{ str_limit($post->body,'50') }} </p>
								<div class="comment-section">
									<li class="comment-btn"> 
									@guest 
									<a href="javascript:void(0);" onclick="toastr.info('To add favorite list. You need to login first.','Info',
									{
										closeButton:true,
										progressBar: true,
										
									})"><i class="fas fa-heart"> </i>  {{ $post->favorite_to_users->count() }}</a> 
									</li>
									@else
									
									<a href="javascript:void(0);" onclick="document.getElementById('favorite-form-{{ $post->id }}').submit();" 
									class="{{ !Auth::user()->favorite_posts->where('pivot.post_id',$post->id)->count() == 0 ? 'favorite_posts' : '' }}">
									<i class="fas fa-heart "> </i>  
									{{ $post->favorite_to_users->count() }}</a>
									<form id="favorite-form-{{ $post->id }}" action="{{ route('post.favorite',$post->id )}}" method="POST" style="display: none;">
										@csrf
									</form>
								
									
									@endguest

								
									<li class="comment-btn"> <a href=""> <i class="fas fa-comment"></i>  {{ $post->comments->count() }}</a> </li>
									<li class="comment-btn"> <a href=""><i class="fas fa-eye"></i> {{ $post->view_count }} </a>  </li>
								</div>
					</div>
					
					</div>
				</div> <!-- col-lg-4 -->
			@endforeach
		
		</div> <!-- row -->
		{{ $posts->links()}}
	</div> <!-- container -->
</section> <!-- section-area block-202 -->
<section class="block-303 pb-30">
	<div class="container">
		<div class="row">
			<div class="block-303-top ctr pb-30">
					<h1>AWESOME FIRST CHOICE FONT</h1>
					<p>like and share my font awesome font all it</p>
			</div>
		</div> <!-- row -->
		<div class="row p-20">
			
			<div class="col-lg-4 col-md-12 col-sm-12">
				<div class="block-303-img mb-20">
				<img src="{{ Storage::disk('public')->url('widget/'.$widgets->image)}}" alt="">
				</div>
			</div> <!-- col-lg-12 -->
			<div class="col-lg-8 col-md-12 col-sm-12">
				<div class="block-303-single mb-20">
			
   					<h2>  {{ $widgets->title }}</h2>

				<p>{{ $widgets->body }}</p>
				<button class="btn-1">View more</button>
				</div>
			</div> <!-- col-lg-12 -->
			
		</div> <!-- row -->
		<div class="row p-20">
			@foreach($secondposts as $secondpost)
			<div class="col-lg-8 col-md-12 col-sm-12">
				<div class="block-303-single mb-20">
			
				<h2>{{ $secondpost->title }}</h2>
				
				<p>{{ $secondpost->body }}</p>
				<button class="btn-1">View more</button>
				</div>
			</div> <!-- col-lg-12 -->
			<div class="col-lg-4 col-md-12 col-sm-12">
				<div class="block-303-img mb-20">
				<a href=""><img src="{{ Storage::disk('public')->url('secondpost/'.$secondpost->image)}}" alt=""></a>
				</div>
			</div> <!-- col-lg-12 -->
			@endforeach
		</div> <!-- row -->
	</div> <!-- container -->

</section> <!-- section-area block-202 -->


@endsection
    
