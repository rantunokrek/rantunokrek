<footer id="footer" class="section-footer-area ptb-30">
	<div class="container">
		<div class="row">
			<div class="col-lg-3 col-md-12 col-sm-12">
				<div class="footer-single  mb-20">
					<div class="section-footer-logo hc pr-10 pl-10">
						<a href="#"><h2>Logo Name Here</h2></a>
					   <p>There are many variations of passages of Lorem Ipsum variations of passages variations of passages many of passages variations.... </p>
					</div>
					<div class="footer-social">
						
						<a href=""><i class="fab fa-facebook"></i></a>
						<a href="#"><i class="fab fa-twitter"></i></a>
						<a href="#"><i class="fab fa-pinterest-square"></i></a>
						<a href="#"><i class="fab fa-youtube"></i></a>
						<a href=""><i class="fab fa-behance"></i></a>
					</div>
				</div>  <!-- section-seven -->
			</div> <!-- col-lg-3-->
			<div class="col-lg-3 col-md-12 col-sm-12">
				<div class="footer-single">
					<div class="section-footer-product  hc foo-li pr-10 pl-10 ">
						<a href="">	<h2>Categories</h2></a>
						<ul>
							@foreach($categories as $category)
							<li><a href="{{route('category.posts',$category->slug )}}"> {{ $category->name }}</a></li>
							@endforeach
						</ul>
						
					</div>
				</div>  <!-- section-seven -->
			</div> <!-- col-lg-3-->
			<div class="col-lg-3 col-md-12 col-sm-12">
				<div class="footer-single hc after">
					<h2>My portfolios</h2>
					<div class="portfolios">
						<img src="{{asset('assets/frontend/img/seven-1.jpg')}}" alt="" />
						<img src="{{asset('assets/frontend/img/men.jpg')}}" alt="" />
						<img src="{{asset('assets/frontend/img/b-2.jpg')}}" alt="" />
						<img src="{{asset('assets/frontend/img/image_1.jpg')}}" alt="" />
						<img src="{{asset('assets/frontend/img/six-1.jpg')}}" alt="" />
						<img src="{{asset('assets/frontend/img/three-2.jpg')}}" alt="" />
						<img src="{{asset('assets/frontend/img/b-1.jpg')}}" alt="" />
						<img src="{{asset('assets/frontend/img/b-3.jpg')}}" alt="" />
						
					</div>
				</div>  <!-- section-seven -->
			</div> <!-- col-lg-3 -->
			<div class="col-lg-3 col-md-12 col-sm-12">
				<div class="footer-single contact_area">
					<div class="section-contact  foo hc clearbt pr-10 pl-10">
						<h2>Contact with Us</h2>
						<li class=""><i class="i-front fas fa-map-marker-alt"></i><a href="#">360USA/frontBari modhupur location uskalaya</a></li>
						<li><i class="i-front fas fa-phone-alt"></i><a href="#">+88009987654</a></li>
						<li><i class="i-front fas fa-envelope"></i><a href="#">alomosala@gmail.com</a></li>
						
					</div>
				</div>  <!-- section-seven -->
			</div> <!-- col-lg-3 -->
		</div>  <!-- row -->
		<div class="row">
			<div class="col-md-6">
				<div class="copyright">
					<form  action="{{ route('subscriber.store') }}" method="POST">
					@csrf
						<div class="form-group">
				
                            <input name="email" type="email" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" placeholder="Enter email">
							<button type="submit" class="btn btn-primary">Submit</button>
                    	 </div>
					
					</form>
				</div>
			</div>
			<div class="col-md-6">
				<div class="copyright">
					<span>copyright{{ config('app.name') }}@|2030 all reserved|</span>
				</div>
			</div>
		</div>
	</div> <!-- container -->
</footer> <!-- footer -->