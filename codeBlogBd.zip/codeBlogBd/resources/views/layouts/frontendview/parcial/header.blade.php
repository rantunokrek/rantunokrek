<header class="header-area ">
	<div class="top-area">
		<div class="container">
			<div class="row">
				<div class="col-lg-2 col-md-4 col-sm-12">
					<div class="logo-area">
						<h1>PORTFOLIO</h1>
					</div>
				</div>
				<div class="col-lg-6 col-md-8 col-sm-12 medi-full">
					<div class="nav-section">
						<ul class="navbar">
							<li class=" li-full"><a href="{{route('home')}}">Home</a></li>
							<li class=" li-full"><a href="{{route('post.index')}}">All posts</a></li>
							@guest
							<li class=" li-full"><a href="{{route('login')}}">Login</a></li>
							@else
							@if(Auth::user()->roleId == 1)
							<li class=" li-full"><a href="{{route('admin.dashboard')}}">Dashboard</a></li>
							@endif
							@if(Auth::user()->roleId == 2)
							<li class=" li-full"><a href="{{route('user.dashboard')}}">Dashboard</a></li>
							@endif

							@endguest
	
							<li class=" li-full"><a href="#footer">Contact</a></li>
						</ul>
						
					</div>
				</div>
				<div class="col-lg-4 col-md-8 col-sm-12 medi-full">
					<div class="form-area">
						<form method="GET" action="{{ route('search')}}">
							<button class="form-btn" type="submit"><i class="fas fa-search"></i></button>
							<input class="form-input" value="" name="query" type="text" placeholder="Search">
						</form>
					</div>
				</div>
			</div> <!-- row -->
		</div> <!-- container -->
	</div> <!-- toparea -->
	
</header>
