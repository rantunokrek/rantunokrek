<!DOCTYPE html>

<html lang="{{ str_replace('_', '-', app()->getLocale()) }}">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- CSRF Token -->
    <meta name="csrf-token" content="{{ csrf_token() }}">

    <title> @yield('title') {{ config('app.name', 'Laravel') }}</title>

    <!-- Scripts -->
   

    <!-- Fonts -->
        <link  rel="stylesheet" href="{{asset('assets/frontend/css/fontawesome.min.css')}}" />
		<link  rel="stylesheet" href="{{asset('assets/frontend/css/bootstrap.min.css')}}" />
		<link  rel="stylesheet" href="{{asset('assets/frontend/css/responsive.css')}}" />
		<link  rel="stylesheet" href="{{asset('assets/frontend/css/docs.theme.min.css')}}" />
		<link  rel="stylesheet" href="{{asset('assets/frontend/css/owl.carousel.min.css')}}" />
		<link  rel="stylesheet" href="{{asset('assets/frontend/css/owl.theme.default.min.css')}}" />
        <link rel="stylesheet" href="https://cdn.bootcss.com/toastr.js/latest/css/toastr.min.css">
		<link  rel="stylesheet" href="{{asset('assets/frontend/css/style.css')}}" />
    @stack('css')
</head>
<body>
@include('layouts.frontendview.parcial.header')
@yield('m-content')
@include('layouts.frontendview.parcial.footer')

<script src="{{asset('assets/frontend/js/jquery.min.js')}}"></script>
<script src="{{asset('assets/frontend/js/fontawesome.min.js')}}"></script>
<script src="{{asset('assets/frontend/js/owl.carousel.min.js')}}"></script>


<!-- Bootstrap Core Js -->
<script src="{{asset('assets/frontend/js/bootstrap.min.js')}}"></script>

<!-- Select Plugin Js -->
<!-- <script src="{{asset('assets/backend/plugins/bootstrap-select/js/bootstrap-select.js')}}"></script> -->

<!-- Slimscroll Plugin Js -->


<!-- Waves Effect Plugin Js -->

 <script src="https://cdn.bootcss.com/toastr.js/latest/js/toastr.min.js"></script>
        {!! Toastr::message() !!}

        <script>
            @if($errors->any())
            @foreach($errors->all() as $error)
            toastr.error('{{ $error }}', 'Error',{
                closeButton:true,
                progressBar:true,
            });
            @endforeach
            @endif

        </script>
       <script>
      var owl = $('.owl-carousel');
      owl.owlCarousel({
        margin: 10,
        loop: true,
        responsive: {
          0: {
            items: 1
          },
          600: {
            items: 2
          },
          1000: {
            items: 3
          }
        }
      })
    </script>
 @stack('js')
</body>
</html>
