@extends('layouts.backendView.app')
@section('title','widget')
@push('css')
<!-- index.php for post -->
<style>
    .create h2 {
    color: #ffff!important;
    text-transform: uppercase;
    font-weight: 800;
}
</style>

<!-- <link href="{{asset('assets/backend/plugins/jquery-datatable/skin/bootstrap/css/dataTables.bootstrap.css')}}" rel="stylesheet"> -->
@endpush
@section('backend-contant')
         <div class="container-fluid">

         <div class="block-header">
                  <!-- here Tag button -->
                     <div class="create">
                            
                     <h2 class="btn btn-primary waves-effect ffff ">Create Widget Post  </h2>
                            
                        </div>
                            
                     
                           <br/>

                            <a class="btn btn-primary waves-effect" href="{{route('admin.widget.index')}}">
                                <i class="material-icons">add</i>
                                <span class="white">Add new widget(1 post)</span>
                            </a>
                            <br/>
                            <br>
                         
                            <a class="btn btn-primary waves-effect" href="{{route('admin.secondpost.index')}}">
                                <i class="material-icons">add</i>
                                <span class="white">Add new widget(2 post)</span>
                            </a>
                          
                           
                       
            </div>
        </div>
       



@endsection
@push('js')
 <!-- Jquery DataTable Plugin Js -->
    <script src="{{asset('assets/backend/plugins/jquery-datatable/jquery.dataTables.js')}}"></script>
    <script src="{{asset('assets/backend/plugins/jquery-datatable/skin/bootstrap/js/dataTables.bootstrap.js')}}"></script>
    <script src="{{asset('assets/backend/plugins/jquery-datatable/extensions/export/dataTables.buttons.min.js')}}"></script>
    <script src="{{asset('assets/backend/plugins/jquery-datatable/extensions/export/buttons.flash.min.js')}}"></script>
    <script src="{{asset('assets/backend/plugins/jquery-datatable/extensions/export/jszip.min.js')}}"></script>
    <script src="{{asset('assets/backend/plugins/jquery-datatable/extensions/export/pdfmake.min.js')}}"></script>
    <script src="{{asset('assets/backend/plugins/jquery-datatable/extensions/export/vfs_fonts.js')}}"></script>
    <script src="{{asset('assets/backend/plugins/jquery-datatable/extensions/export/buttons.html5.min.js')}}"></script>
    <script src="{{asset('assets/backend/plugins/jquery-datatable/extensions/export/buttons.print.min.js')}}"></script>
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@10.16.7/dist/sweetalert2.all.min.js"></script>
    <script src="{{asset('assets/backend/js/pages/tables/jquery-datatable.js')}}"></script>
    <script type="text/javascript">
        function deletepost(id){
             
const swalWithBootstrapButtons = Swal.mixin({
  customClass: {
    confirmButton: 'btn btn-success',
    cancelButton: 'btn btn-danger'
  },
  buttonsStyling: true
})

swalWithBootstrapButtons.fire({
  title: 'Are you sure?',
  text: "You won't be able to revert this!",
  icon: 'warning',
  showCancelButton: true,
  confirmButtonText: 'Yes, delete it!',
  cancelButtonText: 'No, cancel!',
  reverseButtons: true
}).then((result) => {
  if (result.isConfirmed) {
   
     event.preventDefault();
     document.getElementById('delete-form'+id).submit();
   
  } else if (
    /* Read more about handling dismissals below */
    result.dismiss === Swal.DismissReason.cancel
  ) {
    swalWithBootstrapButtons.fire(
      'Cancelled',
      'Your Data is safe!)',
      'error'
    )
  }
})
        }
    </script>
@endpush
