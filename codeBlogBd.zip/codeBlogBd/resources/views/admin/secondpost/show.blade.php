<!-- use Illuminate\Support\Facades\Storage; -->
@extends('layouts.backendView.app')
@section('title','secondpost')
@push('css')
<!-- create.php for post -->
<!-- JQuery DataTable Css -->

@endpush
@section('backend-contant')
<div class="container-fluid">
                <div class="block-header">
                <!-- here Tag button -->
                        <a class="btn btn-primary waves-effect" href="{{route('admin.widget.index')}}"> Back </a>
                 
                    
                </div>
            <!-- Vertical Layout -->
            <div class="row clearfix">
                <div class="col-lg-8 col-md-12 col-sm-12 col-xs-12">
                    <div class="card">
                        <div class="header">
                        <h2>
                        {{ $secondpost->title }}
                        <small> Posted By <strong> <a href=""> </a></strong> on {{ $secondpost->created_at }} </small>
                        
                        </h2>
                        </div>
                        <div class="body">
                           {!! $secondpost->body !!}
                          
                        </div>
                    </div>

                    <div class="card">
                        <div class="header bg-cyan">
                        <h2>Feature Image</h2>
                        </div>
                        <div class="body">
                      <img class="img-responsive thumnail" src="{{ Storage::disk('public')->url('secondpost/'.$secondpost->image)}}" alt="">

                     
                        
                        </div>
                    </div>




                </div>
                
            </div>
            

</div>



@endsection
@push('js')
 <!-- Select Plugin Js -->
 <script src="https://cdn.jsdelivr.net/npm/sweetalert2@10.16.7/dist/sweetalert2.all.min.js"></script>
   
 <script src="{{asset('assets')}}/backend/plugins/bootstrap-select/js/bootstrap-select.js"></script>
   
   <script src="{{asset('assets/backend/plugins/tinymce/tinymce.js')}}"></script>
 
   <script>
       $(function () {
  
   //TinyMCE
   tinymce.init({
       selector: "textarea#tinymce",
       theme: "modern",
       height: 300,
       plugins: [
           'advlist autolink lists link image charmap print preview hr anchor pagebreak',
           'searchreplace wordcount visualblocks visualchars code fullscreen',
           'insertdatetime media nonbreaking save table contextmenu directionality',
           'emoticons template paste textcolor colorpicker textpattern imagetools'
       ],
       toolbar1: 'insertfile undo redo | styleselect | bold italic | alignleft aligncenter alignright alignjustify | bullist numlist outdent indent | link image',
       toolbar2: 'print preview media | forecolor backcolor emoticons',
       image_advtab: true
   });
   tinymce.suffix = ".min";
   tinyMCE.baseURL = "{{ asset('assets/backend/plugins/tinymce') }}" ;
});
 
       function approvePost(id){
            
const swalWithBootstrapButtons = Swal.mixin({
 customClass: {
   confirmButton: 'btn btn-success',
   cancelButton: 'btn btn-danger'
 },
 buttonsStyling: true
})

swalWithBootstrapButtons.fire({
 title: 'Are you sure?',
 text: "You want to approve this!",
 icon: 'warning',
 showCancelButton: true,
 confirmButtonText: 'Yes, approve it!',
 cancelButtonText: 'No, cancel!',
 reverseButtons: true
}).then((result) => {
 if (result.isConfirmed) {
  
    event.preventDefault();
    document.getElementById('approval-form').submit();
  
 } else if (
   /* Read more about handling dismissals below */
   result.dismiss === Swal.DismissReason.cancel
 ) {
   swalWithBootstrapButtons.fire(
     'Cancelled',
     'The post remain pending!)',
     'info'
   )
 }
})
       }
   </script>
@endpush
