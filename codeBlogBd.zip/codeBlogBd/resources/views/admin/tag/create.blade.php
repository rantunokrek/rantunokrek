@extends('layouts.backendView.app')
@section('title','Tag')
@push('css')
<!-- JQuery DataTable Css -->
<link href="{{asset('assets/backend/plugins/jquery-datatable/skin/bootstrap/css/dataTables.bootstrap.css')}}" rel="stylesheet">
@endpush
@section('backend-contant')
<div class="container-fluid">
         
            <!-- Vertical Layout -->
            <div class="row clearfix">
                <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                    <div class="card">
                        <div class="header">
                        <h2>Add Tew Tag</h2>
                        </div>
                        <div class="body">
                            <form action="{{route('admin.tag.store')}}" method="post">
                                @csrf
    
                                <div class="form-group">
                                    <div class="form-line">
                                        <input type="text" name="name" class="form-control" placeholder="Add New Tag" >
                    
                                    </div>
                                </div>
                               <br>
                                <a href="{{route('admin.tag.index')}}" class="btn btn-danger m-t-15 waves-effect">Back</a>
                                <button type="submit" class="btn btn-primary m-t-15 waves-effect">Submit</button>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
            <!-- #END# Vertical Layout -->
         
     
            <!-- #END# Multi Column -->
        </div>



@endsection
@push('script')

@endpush
