
@extends('layouts.frontendview.app')
@section('title')

@endsection
@push('css')	

  <style>
  .slider-area 
  	{
    width: 100%;
    height: auto;
    display: block;
    background: url( {{ Storage::disk('public')->url('category/'.$category->image) }} );
    background-repeat: no-repeat;
    background-position: center;
    background-size: cover;
    text-align: center;
	}
	.slider-h1 
	{
	margin-bottom: .5rem;
	line-height: 1.2;
	font-size: 3rem;
	text-transform: uppercase;
	margin: 0;
	font-weight: 800;
	text-shadow: #efefef 8px 1px 17px;
	display: inline-block;
	}
    .favorite_posts
	{
	color:blue;
	}

  </style>

@endpush
@section('m-content')
<div class="slider-area">
	<div class="container">
		<div class="row">
			<div class="col-lg-12 col-md-12 col-sm-12">
				<div class="slider-text">
					<h1 class="slider-h1">{{$category->name}}</h1>
				</div>
			</div> <!-- col-lg-12 -->
		</div> <!-- row -->
	</div> <!-- container -->
</div> <!-- slider-area -->
    <!-- ======== block-202 ========= -->
<section class="block-202 wh-100 ptb-60">
	<div class="container">
		<div class="row">
			@if($posts->count() > 0 )
			@foreach($posts as $post)
			<div class="col-lg-4 col-md-6 col-sm-12">
				<div class="block-202-single mb-40">
					<div class="block-202-img mb-20">
						<a href="{{route('post.details', $post->slug)}}">
						<img src="{{ Storage::disk('public')->url('post/'.$post->image)}}" alt="{{$post->name}}" />
						</a>
				
						<div class="icon-202">
						<img id="i-fa"  src="{{ 
						Storage::disk('public')->url('profile/'.$post->user->image)
					}}" alt="">
						</div>
					</div>
					<div class="text-202 mb-20">
						<h2> <a href="{{route('post.details', $post->slug)}}">{{ $post->title }} </a> </h2>
						<p> {{ str_limit($post->body,'20') }} </p>
						<div class="comment-section">
							<li class="comment-btn"> 
							@guest 
							<a href="javascript:void(0);" onclick="toastr.info('To add favorite list. You need to login first.','Info',
							{
								closeButton:true,
								progressBar: true,
								
							})"><i class="fas fa-heart"> </i>  {{ $post->favorite_to_users->count() }}</a> 
							</li>
							@else
							
							<a href="javascript:void(0);" onclick="document.getElementById('favorite-form-{{ $post->id }}').submit();" 
							class="{{ !Auth::user()->favorite_posts->where('pivot.post_id',$post->id)->count() == 0 ? 'favorite_posts' : '' }}">
							<i class="fas fa-heart "> </i>  
							{{ $post->favorite_to_users->count() }}</a>
							<form id="favorite-form-{{ $post->id }}" action="{{ route('post.favorite',$post->id )}}" method="POST" style="display: none;">
								@csrf
							</form>
						
							
							@endguest

						
							<li class="comment-btn"> <a href=""> <i class="fas fa-comment"></i> </a> 27 </li>
							<li class="comment-btn"> <a href=""><i class="fas fa-eye"></i> {{ $post->view_count }} </a>  </li>
						</div>
					</div>
				</div>
			</div> <!-- col-lg-4 -->
			@endforeach
			@else
			<div class="col-lg-4 col-md-6 col-sm-12">
				<div class="block-202-single mb-40">
					<div class="text-202 mb-20">
						<h2> <strong>Sorry No Post Found</strong> </h2>
					</div>
				</div>
			</div> <!-- col-lg-4 -->
			@endif
     
			
		</div> <!-- row -->
	</div> <!-- container -->
</section> <!-- section-area block-202 -->v
               

 @endsection
  


 

@push('js')	
   <!-- Bootstrap core JavaScript -->
   <script src="vendor/jquery/jquery.min.js"></script>
    <script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>


    <!-- Additional Scripts -->
    <script src="assets/js/custom.js"></script>
    <script src="assets/js/owl.js"></script>
    <script src="assets/js/slick.js"></script>
    <script src="assets/js/isotope.js"></script>
    <script src="assets/js/accordions.js"></script>

@endpush



  </body>

</html>
