<?php

use Illuminate\Support\Facades\View;
use Illuminate\Support\Facades\Auth; 
use Illuminate\Support\Facades\Route;
 use App\Http\Controllers\Admin\TagsController;


/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Auth::routes();


Route::get('/', 'HomeController@index')->name('home');
//route for SubscriberController
Route::post('subscriber','SubscriberController@store')->name('subscriber.store');
//route for SettingsController
// route for single post PostController
Route::get('post/{slug}','PostController@details')->name('post.details');
// route for all posts PostController
Route::get('posts','PostController@index')->name('post.index');



//user/author controller 
Route::get('profile/{UserName}','UserController@profile')->name('user.profile');
//search controller 
Route::get('search','SearchController@search')->name('search');
// route for category $ tag 
Route::get('/category/{slug}','PostController@postByCategory')->name('category.posts');
Route::get('/tag/{slug}','PostController@postByTag')->name('tag.posts');

Route::group(['middleware' =>['auth']], function(){
    Route::post('favorite/{post}/add', 'FavoriteController@add')->name('post.favorite');
    Route::post('comment/{post}', 'CommentController@store')->name('comment.store');
   
    
});

Route::group(['as'=>'admin.','prefix'=>'admin','namespace' =>'Admin','middleware' =>['auth','admin']], function(){
    Route::get('dashboard', 'AdminDashboardController@index')->name('dashboard');
    Route::resource('tag', 'TagsController');
    Route::resource('category', 'CategoryController');
    Route::resource('post', 'PostController');

    Route::resource('widget', 'WidgetController');
    Route::resource('secondpost', 'SecondpostController');

    //route for admin SettingsController
    Route::get('/settings','SettingsController@index')->name('settings');
    Route::put('profile-update','SettingsController@updateProfile')->name('profile.update');
    Route::put('password-update','SettingsController@updatePassword')->name('password.update');

    Route::get('pwdpost','WdpostController@index')->name('wdpost.index');



    Route::get('authors','AuthorController@index')->name('authors.index');
    Route::delete('authors/{id}','AuthorController@destroy')->name('authors.destroy');

    Route::get('/pending/post', 'PostController@pending')->name('post.pending');
    Route::put('/post/{id}/approve', 'PostController@approval')->name('post.approve');
   // for subscribe 
    Route::get('/subscriber', 'SubscriberController@index')->name('subscriber.index');
    Route::delete('/subscriber/{subscriber}', 'SubscriberController@destroy')->name('subscriber.destroy');
    
    Route::get('comments','CommentController@index')->name('comment.index');
    Route::delete('comments/{id}','CommentController@destroy')->name('comment.destroy');

    // admin route for FavoriteContr4oller 
    Route::get('/favorite', 'FavoriteController@index')->name('favorite.index');
    
});
Route::group(['as'=>'user.','prefix'=>'user','namespace' =>'User','middleware' =>['auth','user']], function(){
    Route::get('dashboard', 'UserDashboardController@index')->name('dashboard');
    Route::resource('post', 'PostController');
     //route for author/user  SettingsController
     Route::get('/settings','SettingsController@index')->name('settings');
     Route::put('profile-update','SettingsController@updateProfile')->name('profile.update');
     Route::put('password-update','SettingsController@updatePassword')->name('password.update');
     // user  route for FavoriteController 
    Route::get('/favorite', 'FavoriteController@index')->name('favorite.index');


    Route::get('comments','CommentController@index')->name('comment.index');
    Route::delete('comments/{id}','CommentController@destroy')->name('comment.destroy');

});

View::composer('layouts.frontendview.parcial.footer',function ($view) {
    $categories = App\Models\Category::all();
    $view->with('categories',$categories);
});