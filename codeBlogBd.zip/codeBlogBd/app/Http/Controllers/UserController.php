<?php

namespace App\Http\Controllers;

use App\Models\User;
use Illuminate\Http\Request;
use Illuminate\Database\Eloquent\Model;

class UserController extends Controller
{
    public function profile($UserName){
       $author = User::where('UserName',$UserName)->first();
        $posts = $author->posts()->approved()->published()->get();
        return view('profile',compact('author','posts'));
    }
}
