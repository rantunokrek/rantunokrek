<?php

namespace App\Http\Controllers;


use Carbon\Carbon;

use App\Models\Post;

use App\Models\Widget;
use App\Models\Category;
use App\Models\Secondpost;
use App\Http\Controllers\Controller;


class HomeController extends Controller
{
    /**
     * Create a new controller instance.
     *
     * @return void
     */
  



    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Contracts\Support\Renderable
     */
    public function index()
    {
        $categories = Category::all();
       
        $posts = Post::latest()->approved()->published()->paginate(6);
        $widgets = Widget::find(1);
        $secondposts = Secondpost::all();
        return view('welcome', compact('categories','posts','widgets','secondposts'));
    }
    
}
