<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;

class WdpostController extends Controller
{
    public function index()
    {
      return view('admin.wdpost.index');
    }
}
