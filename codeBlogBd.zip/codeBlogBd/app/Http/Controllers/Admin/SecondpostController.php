<?php

namespace App\Http\Controllers\Admin;

use Carbon\Carbon;
use App\Models\Secondpost;
use App\Models\Tag;
use App\Models\Category;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Brian2694\Toastr\Facades\Toastr;
use Intervention\Image\Facades\Image;
use Illuminate\Support\Facades\Storage;


class SecondpostController extends Controller
{
  
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
         $secondposts = Secondpost::all();
       return view('admin.secondpost.index', compact('secondposts'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
       $categories = Category::all();
       $tags = Tag::all();
       return view('admin.secondpost.create', compact('categories','tags'));
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $this->validate( $request,[

            'title' => 'required',
            'image' => 'required',
           
            'body' => 'required',
        ]);
        $image = $request->file('image');
        $slug = str_slug($request->title);
        if (isset($image)) {
            // make uniqe name for image 
           $currentDaate =  Carbon::now()->toDateString();
           $imageName = $slug. '-' .uniqid().'.'.$image->getClientOriginalExtension();
           if (!Storage::disk('public')->exists('secondpost')) 
           {
              Storage::disk('public')->makeDirectory('secondpost');
           }
             // Resize image for category slider and upload
          Image::make($image)->resize(1600, 1066)->save(storage_path('app/public/secondpost/') .$imageName);
       
        } else {
            $imageName = "default.png";
        }
        $secondpost = new secondpost();

        $secondpost->title = $request->title;
        $secondpost->image = $imageName;
        $secondpost->body = $request->body;
       
        
        $secondpost->save();
      
        Toastr::success('secondpost successfully saved:','Success');
        return redirect()->route('admin.secondpost.index');


    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Models\Secondpost  $secondpost
     * @return \Illuminate\Http\Response
     */
    public function show(Secondpost $secondpost)
    {
        
        return view('admin.secondpost.show', compact('secondpost'));
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Models\secondpost  $secondpost
     * @return \Illuminate\Http\Response
     */
    public function edit(Secondpost $secondpost)
    {
        
        return view('admin.secondpost.edit', compact('secondpost'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Models\Decondpost  $secondpost
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, Secondpost $secondpost)
    {
        $this->validate( $request,[

            'title' => 'required',
            'image' => 'image',
           
            'body' => 'required',
        ]);
        $image = $request->file('image');
        $slug = str_slug($request->title);
        if (isset($image)) {
            // make uniqe name for image 
           $currentDaate =  Carbon::now()->toDateString();
           $imageName = $slug. '-' .uniqid().'.'.$image->getClientOriginalExtension();
           if (!Storage::disk('public')->exists('secondpost')) 
           {
              Storage::disk('public')->makeDirectory('secondpost');
           }
             // delete old image
             if (Storage::disk('public')->exists('secondpost/'.$secondpost->image)) {
                Storage::disk('public')->delete('secondpost/'.$secondpost->image);
             }
             // Resize image for category slider and upload
          Image::make($image)->resize(1600, 1066)->save(storage_path('app/public/secondpost/') .$imageName);
       
        } else {
            $imageName = $secondpost->image;
        }
        
    
        $secondpost->title = $request->title;
        $secondpost->image = $imageName;
        $secondpost->body = $request->body;
      
        
        $secondpost->save();
     
        Toastr::success('Post successfully Updated:','Success');
        return redirect()->route('admin.secondpost.index');
    }





    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Models\secondpost  $secondpost
     * @return \Illuminate\Http\Response
     */
    public function destroy(Secondpost $secondpost)
    {
       if(Storage::disk('public')->exists('secondpost/'.$secondpost->image)){
        Storage::disk('public')->delete('secondpost/'.$secondpost->image);
       }
      
       $secondpost->delete();
       Toastr::success('secondpost successfully Updated:','Success');
       return redirect()->route('admin.secondpost.index');
    }
}
