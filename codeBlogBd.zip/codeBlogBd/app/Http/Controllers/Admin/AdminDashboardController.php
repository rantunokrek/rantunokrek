<?php

namespace App\Http\Controllers\Admin;

use Carbon\Carbon;
use App\Models\Tag;
use App\Models\Post;
use App\Models\User;
use App\Models\Category;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;

class AdminDashboardController extends Controller
{
   public function index(){
                $posts = Post::all();
                $popular_posts = Post::withCount('comments')
                        ->withCount('favorite_to_users')
                        ->orderBy('view_count','desc')
                        ->orderBy('comments_count','desc')
                        ->orderBy('favorite_to_users_count','desc')
                        ->take(5)->get();
                $total_pending_posts = Post::where('is_approved', false)->count();
                $all_posts = Post::sum('view_count');
                $author_count = User::where('roleId',2)->count(); 
                $new_author_todays = User::where('roleId',2)
                        ->whereDate('created_at',Carbon::today())->count();  
                $active_authors = User::where('roleId',2)
                         ->withCount('posts')       
                         ->withCount('comments')       
                         ->withCount('favorite_posts')       
                         ->orderBy('posts_count','desc')       
                         ->orderBy('comments_count','desc')       
                         ->orderBy('favorite_posts_count','desc')->get();   
                 $category_count = Category::all()->count();
                 $tag_count      = Tag::all()->count();
                            
       return view('admin.dashboard',compact('posts','popular_posts','total_pending_posts',
                                            'all_posts','author_count','new_author_todays',
                                            'active_authors','category_count','tag_count'));
   }
}
