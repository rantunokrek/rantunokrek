<?php

namespace App\Http\Controllers\Admin;

use Carbon\Carbon;
use App\Models\Widget;
use App\Models\Tag;
use App\Models\Category;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Brian2694\Toastr\Facades\Toastr;
use Intervention\Image\Facades\Image;
use Illuminate\Support\Facades\Storage;


class WidgetController extends Controller
{
  
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
         $widgets = Widget::all();
       return view('admin.widget.index', compact('widgets'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
       $categories = Category::all();
       $tags = Tag::all();
       return view('admin.widget.create', compact('categories','tags'));
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $this->validate( $request,[

            'title' => 'required',
            'image' => 'required',
           
            'body' => 'required',
        ]);
        $image = $request->file('image');
        $slug = str_slug($request->title);
        if (isset($image)) {
            // make uniqe name for image 
           $currentDaate =  Carbon::now()->toDateString();
           $imageName = $slug. '-' .uniqid().'.'.$image->getClientOriginalExtension();
           if (!Storage::disk('public')->exists('widget')) 
           {
              Storage::disk('public')->makeDirectory('widget');
           }
             // Resize image for category slider and upload
          Image::make($image)->resize(1600, 1066)->save(storage_path('app/public/widget/') .$imageName);
       
        } else {
            $imageName = "default.png";
        }
        $widget = new widget();

        $widget->title = $request->title;
        $widget->image = $imageName;
        $widget->body = $request->body;
       
        
        $widget->save();
      
        Toastr::success('widget successfully saved:','Success');
        return redirect()->route('admin.widget.index');


    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Models\Widgets  $widget
     * @return \Illuminate\Http\Response
     */
    public function show(Widget $widget)
    {
        
        return view('admin.widget.show', compact('widget'));
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Models\widget  $widget
     * @return \Illuminate\Http\Response
     */
    public function edit(Widget $widget)
    {
        
        return view('admin.widget.edit', compact('widget'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Models\Widget  $widget
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, Widget $widget)
    {
        $this->validate( $request,[

            'title' => 'required',
            'image' => 'image',
           
            'body' => 'required',
        ]);
        $image = $request->file('image');
        $slug = str_slug($request->title);
        if (isset($image)) {
            // make uniqe name for image 
           $currentDaate =  Carbon::now()->toDateString();
           $imageName = $slug. '-' .uniqid().'.'.$image->getClientOriginalExtension();
           if (!Storage::disk('public')->exists('widget')) 
           {
              Storage::disk('public')->makeDirectory('widget');
           }
             // delete old image
             if (Storage::disk('public')->exists('widget/'.$widget->image)) {
                Storage::disk('public')->delete('widget/'.$widget->image);
             }
             // Resize image for category slider and upload
          Image::make($image)->resize(1600, 1066)->save(storage_path('app/public/widget/') .$imageName);
       
        } else {
            $imageName = $widget->image;
        }
        
    
        $widget->title = $request->title;
        $widget->image = $imageName;
        $widget->body = $request->body;
      
        
        $widget->save();
     
        Toastr::success('Post successfully Updated:','Success');
        return redirect()->route('admin.widget.index');
    }





    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Models\widget  $widget
     * @return \Illuminate\Http\Response
     */
    public function destroy(Widget $widget)
    {
       if(Storage::disk('public')->exists('widget/'.$widget->image)){
        Storage::disk('public')->delete('widget/'.$widget->image);
       }
      
       $widget->delete();
       Toastr::success('widget successfully Updated:','Success');
       return redirect()->route('admin.widget.index');
    }
}
