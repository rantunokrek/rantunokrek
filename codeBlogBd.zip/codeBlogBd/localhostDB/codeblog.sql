-- phpMyAdmin SQL Dump
-- version 5.0.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Aug 06, 2021 at 07:17 PM
-- Server version: 10.4.14-MariaDB
-- PHP Version: 7.4.10

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `codeblog`
--

-- --------------------------------------------------------

--
-- Table structure for table `categories`
--

CREATE TABLE `categories` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `slug` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `image` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'default.png',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `categories`
--

INSERT INTO `categories` (`id`, `name`, `slug`, `image`, `created_at`, `updated_at`) VALUES
(1, 'htmlbangla', 'htmlbangla', 'htmlbangla-2021-07-19-60f5ea50700e0.jpg', '2021-07-19 15:10:41', '2021-07-19 15:10:41'),
(2, 'cssbangla', 'cssbangla', 'cssbangla-2021-07-19-60f5ea669f841.jpg', '2021-07-19 15:11:03', '2021-07-19 15:11:03'),
(3, 'wordpressbangla', 'wordpressbangla', 'wordpressbangla-2021-07-19-60f5ea7dcf99f.PNG', '2021-07-19 15:11:27', '2021-07-19 15:11:27');

-- --------------------------------------------------------

--
-- Table structure for table `category_post`
--

CREATE TABLE `category_post` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `post_id` int(11) NOT NULL,
  `category_id` int(11) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `category_post`
--

INSERT INTO `category_post` (`id`, `post_id`, `category_id`, `created_at`, `updated_at`) VALUES
(1, 1, 1, '2021-07-19 15:12:48', '2021-07-19 15:12:48'),
(2, 2, 2, '2021-07-19 15:13:44', '2021-07-19 15:13:44'),
(3, 3, 3, '2021-07-19 15:14:21', '2021-07-19 15:14:21'),
(4, 4, 1, '2021-07-20 14:07:55', '2021-07-20 14:07:55'),
(5, 5, 1, '2021-07-20 14:41:28', '2021-07-20 14:41:28'),
(6, 6, 2, '2021-07-21 02:13:53', '2021-07-21 02:13:53'),
(7, 7, 3, '2021-07-24 13:09:55', '2021-07-24 13:09:55'),
(8, 8, 1, '2021-07-24 13:11:41', '2021-07-24 13:11:41'),
(9, 9, 1, '2021-07-26 13:01:35', '2021-07-26 13:01:35'),
(10, 10, 1, '2021-07-26 13:03:30', '2021-07-26 13:03:30'),
(11, 11, 1, '2021-07-28 10:59:40', '2021-07-28 10:59:40'),
(12, 12, 1, '2021-07-31 11:53:39', '2021-07-31 11:53:39');

-- --------------------------------------------------------

--
-- Table structure for table `comments`
--

CREATE TABLE `comments` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `post_id` bigint(20) UNSIGNED NOT NULL,
  `user_id` int(10) UNSIGNED NOT NULL,
  `comment` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `comments`
--

INSERT INTO `comments` (`id`, `post_id`, `user_id`, `comment`, `created_at`, `updated_at`) VALUES
(1, 2, 1, 'hfhf', '2021-07-19 15:14:53', '2021-07-19 15:14:53'),
(2, 3, 1, 'hcfh', '2021-07-19 15:18:38', '2021-07-19 15:18:38'),
(3, 1, 1, 'vbcxbxbcbc', '2021-07-19 15:30:31', '2021-07-19 15:30:31'),
(4, 2, 1, 'hrelll', '2021-07-19 22:30:02', '2021-07-19 22:30:02'),
(5, 2, 1, 'hjgfj', '2021-07-20 12:54:11', '2021-07-20 12:54:11'),
(6, 1, 1, 'This is html class', '2021-07-20 12:58:33', '2021-07-20 12:58:33'),
(7, 2, 1, 'fhfcjf', '2021-07-20 13:04:15', '2021-07-20 13:04:15'),
(8, 2, 1, 'ia ma fhsa', '2021-07-20 13:51:57', '2021-07-20 13:51:57'),
(9, 3, 2, 'ami author theke bolchi', '2021-07-20 14:00:20', '2021-07-20 14:00:20'),
(11, 1, 2, 'So I’m upgrading my old site from 2.55 to the latest version (kinda outdated piece of software please don’t laugh), so I followed the instruction from this page https://docs.expressionengine.com/v3/installation/upgrade_from_2.x.html, check modules, permissions etc. and viewed the site at http://dev.local/system I got Exception Caught error', '2021-07-20 14:18:23', '2021-07-20 14:18:23'),
(15, 2, 2, 'dbcbcbcbc', '2021-07-22 13:52:15', '2021-07-22 13:52:15'),
(16, 2, 2, 'bbvmngngf', '2021-07-22 13:52:47', '2021-07-22 13:52:47'),
(17, 5, 2, 'xnncfnfn', '2021-07-22 13:54:45', '2021-07-22 13:54:45'),
(18, 6, 2, 'cb c', '2021-07-22 13:55:18', '2021-07-22 13:55:18');

-- --------------------------------------------------------

--
-- Table structure for table `failed_jobs`
--

CREATE TABLE `failed_jobs` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `uuid` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `connection` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `queue` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `payload` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `exception` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `failed_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `jobs`
--

CREATE TABLE `jobs` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `queue` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `payload` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `attempts` tinyint(3) UNSIGNED NOT NULL,
  `reserved_at` int(10) UNSIGNED DEFAULT NULL,
  `available_at` int(10) UNSIGNED NOT NULL,
  `created_at` int(10) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `jobs`
--

INSERT INTO `jobs` (`id`, `queue`, `payload`, `attempts`, `reserved_at`, `available_at`, `created_at`) VALUES
(1, 'default', '{\"uuid\":\"2cc69277-4dd7-4bb6-9eee-9836c80864c9\",\"displayName\":\"App\\\\Notifications\\\\NewAuthorPost\",\"job\":\"Illuminate\\\\Queue\\\\CallQueuedHandler@call\",\"maxTries\":null,\"maxExceptions\":null,\"backoff\":\"\",\"timeout\":null,\"retryUntil\":null,\"data\":{\"commandName\":\"Illuminate\\\\Notifications\\\\SendQueuedNotifications\",\"command\":\"O:48:\\\"Illuminate\\\\Notifications\\\\SendQueuedNotifications\\\":16:{s:11:\\\"notifiables\\\";O:45:\\\"Illuminate\\\\Contracts\\\\Database\\\\ModelIdentifier\\\":4:{s:5:\\\"class\\\";s:15:\\\"App\\\\Models\\\\User\\\";s:2:\\\"id\\\";a:1:{i:0;i:1;}s:9:\\\"relations\\\";a:0:{}s:10:\\\"connection\\\";s:5:\\\"mysql\\\";}s:12:\\\"notification\\\";O:31:\\\"App\\\\Notifications\\\\NewAuthorPost\\\":12:{s:4:\\\"post\\\";O:45:\\\"Illuminate\\\\Contracts\\\\Database\\\\ModelIdentifier\\\":4:{s:5:\\\"class\\\";s:15:\\\"App\\\\Models\\\\Post\\\";s:2:\\\"id\\\";i:4;s:9:\\\"relations\\\";a:0:{}s:10:\\\"connection\\\";s:5:\\\"mysql\\\";}s:2:\\\"id\\\";s:36:\\\"3b2b4e05-ec70-4ed3-bfca-14d2ac0fb52a\\\";s:6:\\\"locale\\\";N;s:10:\\\"connection\\\";N;s:5:\\\"queue\\\";N;s:15:\\\"chainConnection\\\";N;s:10:\\\"chainQueue\\\";N;s:19:\\\"chainCatchCallbacks\\\";N;s:5:\\\"delay\\\";N;s:11:\\\"afterCommit\\\";N;s:10:\\\"middleware\\\";a:0:{}s:7:\\\"chained\\\";a:0:{}}s:8:\\\"channels\\\";a:1:{i:0;s:4:\\\"mail\\\";}s:5:\\\"tries\\\";N;s:7:\\\"timeout\\\";N;s:17:\\\"shouldBeEncrypted\\\";b:0;s:3:\\\"job\\\";N;s:10:\\\"connection\\\";N;s:5:\\\"queue\\\";N;s:15:\\\"chainConnection\\\";N;s:10:\\\"chainQueue\\\";N;s:19:\\\"chainCatchCallbacks\\\";N;s:5:\\\"delay\\\";N;s:11:\\\"afterCommit\\\";N;s:10:\\\"middleware\\\";a:0:{}s:7:\\\"chained\\\";a:0:{}}\"}}', 0, NULL, 1626811677, 1626811677),
(2, 'default', '{\"uuid\":\"8192aefd-a211-44ec-8656-bf5dfa084d94\",\"displayName\":\"App\\\\Notifications\\\\NewAuthorPost\",\"job\":\"Illuminate\\\\Queue\\\\CallQueuedHandler@call\",\"maxTries\":null,\"maxExceptions\":null,\"backoff\":\"\",\"timeout\":null,\"retryUntil\":null,\"data\":{\"commandName\":\"Illuminate\\\\Notifications\\\\SendQueuedNotifications\",\"command\":\"O:48:\\\"Illuminate\\\\Notifications\\\\SendQueuedNotifications\\\":16:{s:11:\\\"notifiables\\\";O:45:\\\"Illuminate\\\\Contracts\\\\Database\\\\ModelIdentifier\\\":4:{s:5:\\\"class\\\";s:15:\\\"App\\\\Models\\\\User\\\";s:2:\\\"id\\\";a:1:{i:0;i:1;}s:9:\\\"relations\\\";a:0:{}s:10:\\\"connection\\\";s:5:\\\"mysql\\\";}s:12:\\\"notification\\\";O:31:\\\"App\\\\Notifications\\\\NewAuthorPost\\\":12:{s:4:\\\"post\\\";O:45:\\\"Illuminate\\\\Contracts\\\\Database\\\\ModelIdentifier\\\":4:{s:5:\\\"class\\\";s:15:\\\"App\\\\Models\\\\Post\\\";s:2:\\\"id\\\";i:5;s:9:\\\"relations\\\";a:0:{}s:10:\\\"connection\\\";s:5:\\\"mysql\\\";}s:2:\\\"id\\\";s:36:\\\"b6007f04-234e-49c5-bafe-b8d9d320ded3\\\";s:6:\\\"locale\\\";N;s:10:\\\"connection\\\";N;s:5:\\\"queue\\\";N;s:15:\\\"chainConnection\\\";N;s:10:\\\"chainQueue\\\";N;s:19:\\\"chainCatchCallbacks\\\";N;s:5:\\\"delay\\\";N;s:11:\\\"afterCommit\\\";N;s:10:\\\"middleware\\\";a:0:{}s:7:\\\"chained\\\";a:0:{}}s:8:\\\"channels\\\";a:1:{i:0;s:4:\\\"mail\\\";}s:5:\\\"tries\\\";N;s:7:\\\"timeout\\\";N;s:17:\\\"shouldBeEncrypted\\\";b:0;s:3:\\\"job\\\";N;s:10:\\\"connection\\\";N;s:5:\\\"queue\\\";N;s:15:\\\"chainConnection\\\";N;s:10:\\\"chainQueue\\\";N;s:19:\\\"chainCatchCallbacks\\\";N;s:5:\\\"delay\\\";N;s:11:\\\"afterCommit\\\";N;s:10:\\\"middleware\\\";a:0:{}s:7:\\\"chained\\\";a:0:{}}\"}}', 0, NULL, 1626813688, 1626813688),
(3, 'default', '{\"uuid\":\"dd93c5b2-a372-4c68-af59-a0afb25ef301\",\"displayName\":\"App\\\\Notifications\\\\NewAuthorPost\",\"job\":\"Illuminate\\\\Queue\\\\CallQueuedHandler@call\",\"maxTries\":null,\"maxExceptions\":null,\"backoff\":\"\",\"timeout\":null,\"retryUntil\":null,\"data\":{\"commandName\":\"Illuminate\\\\Notifications\\\\SendQueuedNotifications\",\"command\":\"O:48:\\\"Illuminate\\\\Notifications\\\\SendQueuedNotifications\\\":16:{s:11:\\\"notifiables\\\";O:45:\\\"Illuminate\\\\Contracts\\\\Database\\\\ModelIdentifier\\\":4:{s:5:\\\"class\\\";s:15:\\\"App\\\\Models\\\\User\\\";s:2:\\\"id\\\";a:1:{i:0;i:1;}s:9:\\\"relations\\\";a:0:{}s:10:\\\"connection\\\";s:5:\\\"mysql\\\";}s:12:\\\"notification\\\";O:31:\\\"App\\\\Notifications\\\\NewAuthorPost\\\":12:{s:4:\\\"post\\\";O:45:\\\"Illuminate\\\\Contracts\\\\Database\\\\ModelIdentifier\\\":4:{s:5:\\\"class\\\";s:15:\\\"App\\\\Models\\\\Post\\\";s:2:\\\"id\\\";i:7;s:9:\\\"relations\\\";a:0:{}s:10:\\\"connection\\\";s:5:\\\"mysql\\\";}s:2:\\\"id\\\";s:36:\\\"21a5919e-4e6d-4d76-8573-b6b9787e8b43\\\";s:6:\\\"locale\\\";N;s:10:\\\"connection\\\";N;s:5:\\\"queue\\\";N;s:15:\\\"chainConnection\\\";N;s:10:\\\"chainQueue\\\";N;s:19:\\\"chainCatchCallbacks\\\";N;s:5:\\\"delay\\\";N;s:11:\\\"afterCommit\\\";N;s:10:\\\"middleware\\\";a:0:{}s:7:\\\"chained\\\";a:0:{}}s:8:\\\"channels\\\";a:1:{i:0;s:4:\\\"mail\\\";}s:5:\\\"tries\\\";N;s:7:\\\"timeout\\\";N;s:17:\\\"shouldBeEncrypted\\\";b:0;s:3:\\\"job\\\";N;s:10:\\\"connection\\\";N;s:5:\\\"queue\\\";N;s:15:\\\"chainConnection\\\";N;s:10:\\\"chainQueue\\\";N;s:19:\\\"chainCatchCallbacks\\\";N;s:5:\\\"delay\\\";N;s:11:\\\"afterCommit\\\";N;s:10:\\\"middleware\\\";a:0:{}s:7:\\\"chained\\\";a:0:{}}\"}}', 0, NULL, 1627153797, 1627153797),
(4, 'default', '{\"uuid\":\"79e19b3f-8a08-4c11-8ce5-1ffd04421c41\",\"displayName\":\"App\\\\Notifications\\\\NewAuthorPost\",\"job\":\"Illuminate\\\\Queue\\\\CallQueuedHandler@call\",\"maxTries\":null,\"maxExceptions\":null,\"backoff\":\"\",\"timeout\":null,\"retryUntil\":null,\"data\":{\"commandName\":\"Illuminate\\\\Notifications\\\\SendQueuedNotifications\",\"command\":\"O:48:\\\"Illuminate\\\\Notifications\\\\SendQueuedNotifications\\\":16:{s:11:\\\"notifiables\\\";O:45:\\\"Illuminate\\\\Contracts\\\\Database\\\\ModelIdentifier\\\":4:{s:5:\\\"class\\\";s:15:\\\"App\\\\Models\\\\User\\\";s:2:\\\"id\\\";a:1:{i:0;i:1;}s:9:\\\"relations\\\";a:0:{}s:10:\\\"connection\\\";s:5:\\\"mysql\\\";}s:12:\\\"notification\\\";O:31:\\\"App\\\\Notifications\\\\NewAuthorPost\\\":12:{s:4:\\\"post\\\";O:45:\\\"Illuminate\\\\Contracts\\\\Database\\\\ModelIdentifier\\\":4:{s:5:\\\"class\\\";s:15:\\\"App\\\\Models\\\\Post\\\";s:2:\\\"id\\\";i:8;s:9:\\\"relations\\\";a:0:{}s:10:\\\"connection\\\";s:5:\\\"mysql\\\";}s:2:\\\"id\\\";s:36:\\\"5d2edb5e-6312-4bb7-8e02-57857def98bf\\\";s:6:\\\"locale\\\";N;s:10:\\\"connection\\\";N;s:5:\\\"queue\\\";N;s:15:\\\"chainConnection\\\";N;s:10:\\\"chainQueue\\\";N;s:19:\\\"chainCatchCallbacks\\\";N;s:5:\\\"delay\\\";N;s:11:\\\"afterCommit\\\";N;s:10:\\\"middleware\\\";a:0:{}s:7:\\\"chained\\\";a:0:{}}s:8:\\\"channels\\\";a:1:{i:0;s:4:\\\"mail\\\";}s:5:\\\"tries\\\";N;s:7:\\\"timeout\\\";N;s:17:\\\"shouldBeEncrypted\\\";b:0;s:3:\\\"job\\\";N;s:10:\\\"connection\\\";N;s:5:\\\"queue\\\";N;s:15:\\\"chainConnection\\\";N;s:10:\\\"chainQueue\\\";N;s:19:\\\"chainCatchCallbacks\\\";N;s:5:\\\"delay\\\";N;s:11:\\\"afterCommit\\\";N;s:10:\\\"middleware\\\";a:0:{}s:7:\\\"chained\\\";a:0:{}}\"}}', 0, NULL, 1627153901, 1627153901),
(5, 'default', '{\"uuid\":\"b5bac23e-41ad-4533-899d-09c8f1ec720d\",\"displayName\":\"App\\\\Notifications\\\\UserPostApproved\",\"job\":\"Illuminate\\\\Queue\\\\CallQueuedHandler@call\",\"maxTries\":null,\"maxExceptions\":null,\"backoff\":\"\",\"timeout\":null,\"retryUntil\":null,\"data\":{\"commandName\":\"Illuminate\\\\Notifications\\\\SendQueuedNotifications\",\"command\":\"O:48:\\\"Illuminate\\\\Notifications\\\\SendQueuedNotifications\\\":16:{s:11:\\\"notifiables\\\";O:45:\\\"Illuminate\\\\Contracts\\\\Database\\\\ModelIdentifier\\\":4:{s:5:\\\"class\\\";s:15:\\\"App\\\\Models\\\\User\\\";s:2:\\\"id\\\";a:1:{i:0;i:2;}s:9:\\\"relations\\\";a:0:{}s:10:\\\"connection\\\";s:5:\\\"mysql\\\";}s:12:\\\"notification\\\";O:34:\\\"App\\\\Notifications\\\\UserPostApproved\\\":12:{s:4:\\\"post\\\";O:45:\\\"Illuminate\\\\Contracts\\\\Database\\\\ModelIdentifier\\\":4:{s:5:\\\"class\\\";s:15:\\\"App\\\\Models\\\\Post\\\";s:2:\\\"id\\\";i:7;s:9:\\\"relations\\\";a:1:{i:0;s:4:\\\"User\\\";}s:10:\\\"connection\\\";s:5:\\\"mysql\\\";}s:2:\\\"id\\\";s:36:\\\"7d95bf13-0d76-4dea-9d26-810735436e82\\\";s:6:\\\"locale\\\";N;s:10:\\\"connection\\\";N;s:5:\\\"queue\\\";N;s:15:\\\"chainConnection\\\";N;s:10:\\\"chainQueue\\\";N;s:19:\\\"chainCatchCallbacks\\\";N;s:5:\\\"delay\\\";N;s:11:\\\"afterCommit\\\";N;s:10:\\\"middleware\\\";a:0:{}s:7:\\\"chained\\\";a:0:{}}s:8:\\\"channels\\\";a:1:{i:0;s:4:\\\"mail\\\";}s:5:\\\"tries\\\";N;s:7:\\\"timeout\\\";N;s:17:\\\"shouldBeEncrypted\\\";b:0;s:3:\\\"job\\\";N;s:10:\\\"connection\\\";N;s:5:\\\"queue\\\";N;s:15:\\\"chainConnection\\\";N;s:10:\\\"chainQueue\\\";N;s:19:\\\"chainCatchCallbacks\\\";N;s:5:\\\"delay\\\";N;s:11:\\\"afterCommit\\\";N;s:10:\\\"middleware\\\";a:0:{}s:7:\\\"chained\\\";a:0:{}}\"}}', 0, NULL, 1627154195, 1627154195),
(6, 'default', '{\"uuid\":\"b7a8e18c-ce7b-451f-be9f-1ca08d4826bc\",\"displayName\":\"App\\\\Notifications\\\\UserPostApproved\",\"job\":\"Illuminate\\\\Queue\\\\CallQueuedHandler@call\",\"maxTries\":null,\"maxExceptions\":null,\"backoff\":\"\",\"timeout\":null,\"retryUntil\":null,\"data\":{\"commandName\":\"Illuminate\\\\Notifications\\\\SendQueuedNotifications\",\"command\":\"O:48:\\\"Illuminate\\\\Notifications\\\\SendQueuedNotifications\\\":16:{s:11:\\\"notifiables\\\";O:45:\\\"Illuminate\\\\Contracts\\\\Database\\\\ModelIdentifier\\\":4:{s:5:\\\"class\\\";s:15:\\\"App\\\\Models\\\\User\\\";s:2:\\\"id\\\";a:1:{i:0;i:2;}s:9:\\\"relations\\\";a:0:{}s:10:\\\"connection\\\";s:5:\\\"mysql\\\";}s:12:\\\"notification\\\";O:34:\\\"App\\\\Notifications\\\\UserPostApproved\\\":12:{s:4:\\\"post\\\";O:45:\\\"Illuminate\\\\Contracts\\\\Database\\\\ModelIdentifier\\\":4:{s:5:\\\"class\\\";s:15:\\\"App\\\\Models\\\\Post\\\";s:2:\\\"id\\\";i:4;s:9:\\\"relations\\\";a:1:{i:0;s:4:\\\"User\\\";}s:10:\\\"connection\\\";s:5:\\\"mysql\\\";}s:2:\\\"id\\\";s:36:\\\"d134f7fe-2078-4c67-bcbc-0ec225bb1454\\\";s:6:\\\"locale\\\";N;s:10:\\\"connection\\\";N;s:5:\\\"queue\\\";N;s:15:\\\"chainConnection\\\";N;s:10:\\\"chainQueue\\\";N;s:19:\\\"chainCatchCallbacks\\\";N;s:5:\\\"delay\\\";N;s:11:\\\"afterCommit\\\";N;s:10:\\\"middleware\\\";a:0:{}s:7:\\\"chained\\\";a:0:{}}s:8:\\\"channels\\\";a:1:{i:0;s:4:\\\"mail\\\";}s:5:\\\"tries\\\";N;s:7:\\\"timeout\\\";N;s:17:\\\"shouldBeEncrypted\\\";b:0;s:3:\\\"job\\\";N;s:10:\\\"connection\\\";N;s:5:\\\"queue\\\";N;s:15:\\\"chainConnection\\\";N;s:10:\\\"chainQueue\\\";N;s:19:\\\"chainCatchCallbacks\\\";N;s:5:\\\"delay\\\";N;s:11:\\\"afterCommit\\\";N;s:10:\\\"middleware\\\";a:0:{}s:7:\\\"chained\\\";a:0:{}}\"}}', 0, NULL, 1627157998, 1627157998),
(7, 'default', '{\"uuid\":\"81fc8eb1-39a9-461b-be02-09e0a562ba89\",\"displayName\":\"App\\\\Notifications\\\\UserPostApproved\",\"job\":\"Illuminate\\\\Queue\\\\CallQueuedHandler@call\",\"maxTries\":null,\"maxExceptions\":null,\"backoff\":\"\",\"timeout\":null,\"retryUntil\":null,\"data\":{\"commandName\":\"Illuminate\\\\Notifications\\\\SendQueuedNotifications\",\"command\":\"O:48:\\\"Illuminate\\\\Notifications\\\\SendQueuedNotifications\\\":16:{s:11:\\\"notifiables\\\";O:45:\\\"Illuminate\\\\Contracts\\\\Database\\\\ModelIdentifier\\\":4:{s:5:\\\"class\\\";s:15:\\\"App\\\\Models\\\\User\\\";s:2:\\\"id\\\";a:1:{i:0;i:2;}s:9:\\\"relations\\\";a:0:{}s:10:\\\"connection\\\";s:5:\\\"mysql\\\";}s:12:\\\"notification\\\";O:34:\\\"App\\\\Notifications\\\\UserPostApproved\\\":12:{s:4:\\\"post\\\";O:45:\\\"Illuminate\\\\Contracts\\\\Database\\\\ModelIdentifier\\\":4:{s:5:\\\"class\\\";s:15:\\\"App\\\\Models\\\\Post\\\";s:2:\\\"id\\\";i:5;s:9:\\\"relations\\\";a:1:{i:0;s:4:\\\"User\\\";}s:10:\\\"connection\\\";s:5:\\\"mysql\\\";}s:2:\\\"id\\\";s:36:\\\"6a4c2dda-6e80-41d1-8908-2ca162133bb9\\\";s:6:\\\"locale\\\";N;s:10:\\\"connection\\\";N;s:5:\\\"queue\\\";N;s:15:\\\"chainConnection\\\";N;s:10:\\\"chainQueue\\\";N;s:19:\\\"chainCatchCallbacks\\\";N;s:5:\\\"delay\\\";N;s:11:\\\"afterCommit\\\";N;s:10:\\\"middleware\\\";a:0:{}s:7:\\\"chained\\\";a:0:{}}s:8:\\\"channels\\\";a:1:{i:0;s:4:\\\"mail\\\";}s:5:\\\"tries\\\";N;s:7:\\\"timeout\\\";N;s:17:\\\"shouldBeEncrypted\\\";b:0;s:3:\\\"job\\\";N;s:10:\\\"connection\\\";N;s:5:\\\"queue\\\";N;s:15:\\\"chainConnection\\\";N;s:10:\\\"chainQueue\\\";N;s:19:\\\"chainCatchCallbacks\\\";N;s:5:\\\"delay\\\";N;s:11:\\\"afterCommit\\\";N;s:10:\\\"middleware\\\";a:0:{}s:7:\\\"chained\\\";a:0:{}}\"}}', 0, NULL, 1627158016, 1627158016),
(8, 'default', '{\"uuid\":\"3d112ef3-c4de-43a0-b823-ea1829e3abc4\",\"displayName\":\"App\\\\Notifications\\\\UserPostApproved\",\"job\":\"Illuminate\\\\Queue\\\\CallQueuedHandler@call\",\"maxTries\":null,\"maxExceptions\":null,\"backoff\":\"\",\"timeout\":null,\"retryUntil\":null,\"data\":{\"commandName\":\"Illuminate\\\\Notifications\\\\SendQueuedNotifications\",\"command\":\"O:48:\\\"Illuminate\\\\Notifications\\\\SendQueuedNotifications\\\":16:{s:11:\\\"notifiables\\\";O:45:\\\"Illuminate\\\\Contracts\\\\Database\\\\ModelIdentifier\\\":4:{s:5:\\\"class\\\";s:15:\\\"App\\\\Models\\\\User\\\";s:2:\\\"id\\\";a:1:{i:0;i:2;}s:9:\\\"relations\\\";a:0:{}s:10:\\\"connection\\\";s:5:\\\"mysql\\\";}s:12:\\\"notification\\\";O:34:\\\"App\\\\Notifications\\\\UserPostApproved\\\":12:{s:4:\\\"post\\\";O:45:\\\"Illuminate\\\\Contracts\\\\Database\\\\ModelIdentifier\\\":4:{s:5:\\\"class\\\";s:15:\\\"App\\\\Models\\\\Post\\\";s:2:\\\"id\\\";i:8;s:9:\\\"relations\\\";a:1:{i:0;s:4:\\\"User\\\";}s:10:\\\"connection\\\";s:5:\\\"mysql\\\";}s:2:\\\"id\\\";s:36:\\\"66760448-157a-4ea3-aaa5-0e229f9cc7b2\\\";s:6:\\\"locale\\\";N;s:10:\\\"connection\\\";N;s:5:\\\"queue\\\";N;s:15:\\\"chainConnection\\\";N;s:10:\\\"chainQueue\\\";N;s:19:\\\"chainCatchCallbacks\\\";N;s:5:\\\"delay\\\";N;s:11:\\\"afterCommit\\\";N;s:10:\\\"middleware\\\";a:0:{}s:7:\\\"chained\\\";a:0:{}}s:8:\\\"channels\\\";a:1:{i:0;s:4:\\\"mail\\\";}s:5:\\\"tries\\\";N;s:7:\\\"timeout\\\";N;s:17:\\\"shouldBeEncrypted\\\";b:0;s:3:\\\"job\\\";N;s:10:\\\"connection\\\";N;s:5:\\\"queue\\\";N;s:15:\\\"chainConnection\\\";N;s:10:\\\"chainQueue\\\";N;s:19:\\\"chainCatchCallbacks\\\";N;s:5:\\\"delay\\\";N;s:11:\\\"afterCommit\\\";N;s:10:\\\"middleware\\\";a:0:{}s:7:\\\"chained\\\";a:0:{}}\"}}', 0, NULL, 1627158030, 1627158030),
(9, 'default', '{\"uuid\":\"d676a45a-f9bf-46e9-8276-7ba935b773ef\",\"displayName\":\"App\\\\Notifications\\\\NewAuthorPost\",\"job\":\"Illuminate\\\\Queue\\\\CallQueuedHandler@call\",\"maxTries\":null,\"maxExceptions\":null,\"backoff\":\"\",\"timeout\":null,\"retryUntil\":null,\"data\":{\"commandName\":\"Illuminate\\\\Notifications\\\\SendQueuedNotifications\",\"command\":\"O:48:\\\"Illuminate\\\\Notifications\\\\SendQueuedNotifications\\\":16:{s:11:\\\"notifiables\\\";O:45:\\\"Illuminate\\\\Contracts\\\\Database\\\\ModelIdentifier\\\":4:{s:5:\\\"class\\\";s:15:\\\"App\\\\Models\\\\User\\\";s:2:\\\"id\\\";a:1:{i:0;i:1;}s:9:\\\"relations\\\";a:0:{}s:10:\\\"connection\\\";s:5:\\\"mysql\\\";}s:12:\\\"notification\\\";O:31:\\\"App\\\\Notifications\\\\NewAuthorPost\\\":12:{s:4:\\\"post\\\";O:45:\\\"Illuminate\\\\Contracts\\\\Database\\\\ModelIdentifier\\\":4:{s:5:\\\"class\\\";s:15:\\\"App\\\\Models\\\\Post\\\";s:2:\\\"id\\\";i:9;s:9:\\\"relations\\\";a:0:{}s:10:\\\"connection\\\";s:5:\\\"mysql\\\";}s:2:\\\"id\\\";s:36:\\\"387319df-8978-478a-9578-be3a9eabaacd\\\";s:6:\\\"locale\\\";N;s:10:\\\"connection\\\";N;s:5:\\\"queue\\\";N;s:15:\\\"chainConnection\\\";N;s:10:\\\"chainQueue\\\";N;s:19:\\\"chainCatchCallbacks\\\";N;s:5:\\\"delay\\\";N;s:11:\\\"afterCommit\\\";N;s:10:\\\"middleware\\\";a:0:{}s:7:\\\"chained\\\";a:0:{}}s:8:\\\"channels\\\";a:1:{i:0;s:4:\\\"mail\\\";}s:5:\\\"tries\\\";N;s:7:\\\"timeout\\\";N;s:17:\\\"shouldBeEncrypted\\\";b:0;s:3:\\\"job\\\";N;s:10:\\\"connection\\\";N;s:5:\\\"queue\\\";N;s:15:\\\"chainConnection\\\";N;s:10:\\\"chainQueue\\\";N;s:19:\\\"chainCatchCallbacks\\\";N;s:5:\\\"delay\\\";N;s:11:\\\"afterCommit\\\";N;s:10:\\\"middleware\\\";a:0:{}s:7:\\\"chained\\\";a:0:{}}\"}}', 0, NULL, 1627326097, 1627326097),
(10, 'default', '{\"uuid\":\"64a08a77-e7d7-431c-9648-a965649aae53\",\"displayName\":\"App\\\\Notifications\\\\NewAuthorPost\",\"job\":\"Illuminate\\\\Queue\\\\CallQueuedHandler@call\",\"maxTries\":null,\"maxExceptions\":null,\"backoff\":\"\",\"timeout\":null,\"retryUntil\":null,\"data\":{\"commandName\":\"Illuminate\\\\Notifications\\\\SendQueuedNotifications\",\"command\":\"O:48:\\\"Illuminate\\\\Notifications\\\\SendQueuedNotifications\\\":16:{s:11:\\\"notifiables\\\";O:45:\\\"Illuminate\\\\Contracts\\\\Database\\\\ModelIdentifier\\\":4:{s:5:\\\"class\\\";s:15:\\\"App\\\\Models\\\\User\\\";s:2:\\\"id\\\";a:1:{i:0;i:1;}s:9:\\\"relations\\\";a:0:{}s:10:\\\"connection\\\";s:5:\\\"mysql\\\";}s:12:\\\"notification\\\";O:31:\\\"App\\\\Notifications\\\\NewAuthorPost\\\":12:{s:4:\\\"post\\\";O:45:\\\"Illuminate\\\\Contracts\\\\Database\\\\ModelIdentifier\\\":4:{s:5:\\\"class\\\";s:15:\\\"App\\\\Models\\\\Post\\\";s:2:\\\"id\\\";i:10;s:9:\\\"relations\\\";a:0:{}s:10:\\\"connection\\\";s:5:\\\"mysql\\\";}s:2:\\\"id\\\";s:36:\\\"51c5097f-6c7e-4d0e-ba7d-ac25bc9da219\\\";s:6:\\\"locale\\\";N;s:10:\\\"connection\\\";N;s:5:\\\"queue\\\";N;s:15:\\\"chainConnection\\\";N;s:10:\\\"chainQueue\\\";N;s:19:\\\"chainCatchCallbacks\\\";N;s:5:\\\"delay\\\";N;s:11:\\\"afterCommit\\\";N;s:10:\\\"middleware\\\";a:0:{}s:7:\\\"chained\\\";a:0:{}}s:8:\\\"channels\\\";a:1:{i:0;s:4:\\\"mail\\\";}s:5:\\\"tries\\\";N;s:7:\\\"timeout\\\";N;s:17:\\\"shouldBeEncrypted\\\";b:0;s:3:\\\"job\\\";N;s:10:\\\"connection\\\";N;s:5:\\\"queue\\\";N;s:15:\\\"chainConnection\\\";N;s:10:\\\"chainQueue\\\";N;s:19:\\\"chainCatchCallbacks\\\";N;s:5:\\\"delay\\\";N;s:11:\\\"afterCommit\\\";N;s:10:\\\"middleware\\\";a:0:{}s:7:\\\"chained\\\";a:0:{}}\"}}', 0, NULL, 1627326210, 1627326210),
(11, 'default', '{\"uuid\":\"ca220e24-bf0e-41a8-bbd7-3cbf258ba6b9\",\"displayName\":\"App\\\\Notifications\\\\UserPostApproved\",\"job\":\"Illuminate\\\\Queue\\\\CallQueuedHandler@call\",\"maxTries\":null,\"maxExceptions\":null,\"backoff\":\"\",\"timeout\":null,\"retryUntil\":null,\"data\":{\"commandName\":\"Illuminate\\\\Notifications\\\\SendQueuedNotifications\",\"command\":\"O:48:\\\"Illuminate\\\\Notifications\\\\SendQueuedNotifications\\\":16:{s:11:\\\"notifiables\\\";O:45:\\\"Illuminate\\\\Contracts\\\\Database\\\\ModelIdentifier\\\":4:{s:5:\\\"class\\\";s:15:\\\"App\\\\Models\\\\User\\\";s:2:\\\"id\\\";a:1:{i:0;i:5;}s:9:\\\"relations\\\";a:0:{}s:10:\\\"connection\\\";s:5:\\\"mysql\\\";}s:12:\\\"notification\\\";O:34:\\\"App\\\\Notifications\\\\UserPostApproved\\\":12:{s:4:\\\"post\\\";O:45:\\\"Illuminate\\\\Contracts\\\\Database\\\\ModelIdentifier\\\":4:{s:5:\\\"class\\\";s:15:\\\"App\\\\Models\\\\Post\\\";s:2:\\\"id\\\";i:9;s:9:\\\"relations\\\";a:1:{i:0;s:4:\\\"User\\\";}s:10:\\\"connection\\\";s:5:\\\"mysql\\\";}s:2:\\\"id\\\";s:36:\\\"697dbdd8-91ec-4264-97ec-21cd49cd56ba\\\";s:6:\\\"locale\\\";N;s:10:\\\"connection\\\";N;s:5:\\\"queue\\\";N;s:15:\\\"chainConnection\\\";N;s:10:\\\"chainQueue\\\";N;s:19:\\\"chainCatchCallbacks\\\";N;s:5:\\\"delay\\\";N;s:11:\\\"afterCommit\\\";N;s:10:\\\"middleware\\\";a:0:{}s:7:\\\"chained\\\";a:0:{}}s:8:\\\"channels\\\";a:1:{i:0;s:4:\\\"mail\\\";}s:5:\\\"tries\\\";N;s:7:\\\"timeout\\\";N;s:17:\\\"shouldBeEncrypted\\\";b:0;s:3:\\\"job\\\";N;s:10:\\\"connection\\\";N;s:5:\\\"queue\\\";N;s:15:\\\"chainConnection\\\";N;s:10:\\\"chainQueue\\\";N;s:19:\\\"chainCatchCallbacks\\\";N;s:5:\\\"delay\\\";N;s:11:\\\"afterCommit\\\";N;s:10:\\\"middleware\\\";a:0:{}s:7:\\\"chained\\\";a:0:{}}\"}}', 0, NULL, 1627326265, 1627326265),
(12, 'default', '{\"uuid\":\"029b480f-e0ce-4394-9034-d0407823ada2\",\"displayName\":\"App\\\\Notifications\\\\UserPostApproved\",\"job\":\"Illuminate\\\\Queue\\\\CallQueuedHandler@call\",\"maxTries\":null,\"maxExceptions\":null,\"backoff\":\"\",\"timeout\":null,\"retryUntil\":null,\"data\":{\"commandName\":\"Illuminate\\\\Notifications\\\\SendQueuedNotifications\",\"command\":\"O:48:\\\"Illuminate\\\\Notifications\\\\SendQueuedNotifications\\\":16:{s:11:\\\"notifiables\\\";O:45:\\\"Illuminate\\\\Contracts\\\\Database\\\\ModelIdentifier\\\":4:{s:5:\\\"class\\\";s:15:\\\"App\\\\Models\\\\User\\\";s:2:\\\"id\\\";a:1:{i:0;i:5;}s:9:\\\"relations\\\";a:0:{}s:10:\\\"connection\\\";s:5:\\\"mysql\\\";}s:12:\\\"notification\\\";O:34:\\\"App\\\\Notifications\\\\UserPostApproved\\\":12:{s:4:\\\"post\\\";O:45:\\\"Illuminate\\\\Contracts\\\\Database\\\\ModelIdentifier\\\":4:{s:5:\\\"class\\\";s:15:\\\"App\\\\Models\\\\Post\\\";s:2:\\\"id\\\";i:10;s:9:\\\"relations\\\";a:1:{i:0;s:4:\\\"User\\\";}s:10:\\\"connection\\\";s:5:\\\"mysql\\\";}s:2:\\\"id\\\";s:36:\\\"ab5198ff-ad05-492a-b617-c8dbce8d3acf\\\";s:6:\\\"locale\\\";N;s:10:\\\"connection\\\";N;s:5:\\\"queue\\\";N;s:15:\\\"chainConnection\\\";N;s:10:\\\"chainQueue\\\";N;s:19:\\\"chainCatchCallbacks\\\";N;s:5:\\\"delay\\\";N;s:11:\\\"afterCommit\\\";N;s:10:\\\"middleware\\\";a:0:{}s:7:\\\"chained\\\";a:0:{}}s:8:\\\"channels\\\";a:1:{i:0;s:4:\\\"mail\\\";}s:5:\\\"tries\\\";N;s:7:\\\"timeout\\\";N;s:17:\\\"shouldBeEncrypted\\\";b:0;s:3:\\\"job\\\";N;s:10:\\\"connection\\\";N;s:5:\\\"queue\\\";N;s:15:\\\"chainConnection\\\";N;s:10:\\\"chainQueue\\\";N;s:19:\\\"chainCatchCallbacks\\\";N;s:5:\\\"delay\\\";N;s:11:\\\"afterCommit\\\";N;s:10:\\\"middleware\\\";a:0:{}s:7:\\\"chained\\\";a:0:{}}\"}}', 0, NULL, 1627326279, 1627326279),
(13, 'default', '{\"uuid\":\"fa1c83fa-5d14-498a-815c-b8848f85d366\",\"displayName\":\"App\\\\Notifications\\\\NewAuthorPost\",\"job\":\"Illuminate\\\\Queue\\\\CallQueuedHandler@call\",\"maxTries\":null,\"maxExceptions\":null,\"backoff\":\"\",\"timeout\":null,\"retryUntil\":null,\"data\":{\"commandName\":\"Illuminate\\\\Notifications\\\\SendQueuedNotifications\",\"command\":\"O:48:\\\"Illuminate\\\\Notifications\\\\SendQueuedNotifications\\\":16:{s:11:\\\"notifiables\\\";O:45:\\\"Illuminate\\\\Contracts\\\\Database\\\\ModelIdentifier\\\":4:{s:5:\\\"class\\\";s:15:\\\"App\\\\Models\\\\User\\\";s:2:\\\"id\\\";a:1:{i:0;i:1;}s:9:\\\"relations\\\";a:0:{}s:10:\\\"connection\\\";s:5:\\\"mysql\\\";}s:12:\\\"notification\\\";O:31:\\\"App\\\\Notifications\\\\NewAuthorPost\\\":12:{s:4:\\\"post\\\";O:45:\\\"Illuminate\\\\Contracts\\\\Database\\\\ModelIdentifier\\\":4:{s:5:\\\"class\\\";s:15:\\\"App\\\\Models\\\\Post\\\";s:2:\\\"id\\\";i:11;s:9:\\\"relations\\\";a:0:{}s:10:\\\"connection\\\";s:5:\\\"mysql\\\";}s:2:\\\"id\\\";s:36:\\\"cc230b2d-bf66-45f3-a2f9-41a8031f7d24\\\";s:6:\\\"locale\\\";N;s:10:\\\"connection\\\";N;s:5:\\\"queue\\\";N;s:15:\\\"chainConnection\\\";N;s:10:\\\"chainQueue\\\";N;s:19:\\\"chainCatchCallbacks\\\";N;s:5:\\\"delay\\\";N;s:11:\\\"afterCommit\\\";N;s:10:\\\"middleware\\\";a:0:{}s:7:\\\"chained\\\";a:0:{}}s:8:\\\"channels\\\";a:1:{i:0;s:4:\\\"mail\\\";}s:5:\\\"tries\\\";N;s:7:\\\"timeout\\\";N;s:17:\\\"shouldBeEncrypted\\\";b:0;s:3:\\\"job\\\";N;s:10:\\\"connection\\\";N;s:5:\\\"queue\\\";N;s:15:\\\"chainConnection\\\";N;s:10:\\\"chainQueue\\\";N;s:19:\\\"chainCatchCallbacks\\\";N;s:5:\\\"delay\\\";N;s:11:\\\"afterCommit\\\";N;s:10:\\\"middleware\\\";a:0:{}s:7:\\\"chained\\\";a:0:{}}\"}}', 0, NULL, 1627491582, 1627491582);

-- --------------------------------------------------------

--
-- Table structure for table `migrations`
--

CREATE TABLE `migrations` (
  `id` int(10) UNSIGNED NOT NULL,
  `migration` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `migrations`
--

INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES
(1, '2014_10_12_000000_create_users_table', 1),
(2, '2014_10_12_100000_create_password_resets_table', 1),
(3, '2019_08_19_000000_create_failed_jobs_table', 1),
(4, '2021_05_03_163800_create_roles_table', 1),
(5, '2021_05_09_065332_create_tags_table', 1),
(6, '2021_05_14_081904_create_categories_table', 1),
(7, '2021_05_19_183227_create_posts_table', 1),
(8, '2021_05_19_184306_create_category_post_table', 1),
(9, '2021_05_19_184328_create_post_tag_table', 1),
(10, '2021_06_11_185541_create_subscribers_table', 1),
(11, '2021_06_18_185230_create_jobs_table', 1),
(12, '2021_07_15_202905_create_post_user_table', 1),
(13, '2021_07_16_184932_create_comments_table', 1),
(15, '2021_07_31_170155_create_widgets_table', 3),
(16, '2021_08_02_195619_create_widgetsecond_table', 4),
(17, '2021_08_03_173902_create_secondposts_table', 5);

-- --------------------------------------------------------

--
-- Table structure for table `password_resets`
--

CREATE TABLE `password_resets` (
  `email` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `posts`
--

CREATE TABLE `posts` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `user_id` int(10) UNSIGNED NOT NULL,
  `title` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `slug` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `image` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'default.png',
  `body` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `view_count` int(11) NOT NULL DEFAULT 0,
  `status` tinyint(1) NOT NULL DEFAULT 0,
  `is_approved` tinyint(1) NOT NULL DEFAULT 0,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `posts`
--

INSERT INTO `posts` (`id`, `user_id`, `title`, `slug`, `image`, `body`, `view_count`, `status`, `is_approved`, `created_at`, `updated_at`) VALUES
(1, 1, 'html class', 'html-class', 'html-class-60f5ead013d94.jpg', '<p><strong>Lorem Ipsum</strong>&nbsp;is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry\'s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.<strong>Lorem Ipsum</strong>&nbsp;is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry\'s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.</p>', 5, 1, 1, '2021-07-19 15:12:48', '2021-07-21 13:11:30'),
(2, 1, 'css Lorem Ipsum is simply dummy text of th', 'css-lorem-ipsum-is-simply-dummy-text-of-th', 'css-lorem-ipsum-is-simply-dummy-text-of-th-60f5eb073e592.PNG', '<p><strong>Lorem Ipsum</strong>&nbsp;is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry\'s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.<strong>Lorem Ipsum</strong>&nbsp;is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry\'s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.</p>', 8, 1, 1, '2021-07-19 15:13:44', '2021-07-28 13:40:56'),
(3, 1, 'Lorem Ipsum.gdhdhdhdhd hdhh', 'lorem-ipsumgdhdhdhdhd-hdhh', 'lorem-ipsumgdhdhdhdhd-hdhh-60f5eb2d51ae3.jpg', '<p><strong>Lorem Ipsum</strong>&nbsp;is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry\'s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.<strong>Lorem Ipsum</strong>&nbsp;is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry\'s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.<strong>Lorem Ipsum</strong>&nbsp;is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry\'s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.<strong>Lorem Ipsum</strong>&nbsp;is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry\'s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.</p>', 5, 1, 1, '2021-07-19 15:14:21', '2021-07-25 12:23:52'),
(4, 2, 'hello ami author', 'hello-ami-author', 'hello-ami-author-60f72d1a4af3f.jpg', '<p>So I&rsquo;m upgrading my old site from 2.55 to the latest version (kinda outdated piece of software please don&rsquo;t laugh), so I followed the instruction from this page https://docs.expressionengine.com/v3/installation/upgrade_from_2.x.html, check modules, permissions etc. and viewed the site at http://dev.local/system I got Exception Caught errorSo I&rsquo;m upgrading my old site from 2.55 to the latest version (kinda outdated piece of software please don&rsquo;t laugh), so I followed the instruction from this page https://docs.expressionengine.com/v3/installation/upgrade_from_2.x.html, check modules, permissions etc. and viewed the site at http://dev.local/system I got Exception Caught error</p>', 2, 1, 1, '2021-07-20 14:07:55', '2021-07-25 12:53:06'),
(5, 2, 'comment test gfhfhfh', 'comment-test-gfhfhfh', 'comment-test-gfhfhfh-60f734f735444.jpg', '<p>So I&rsquo;m upgrading my old site from 2.55 to the latest version (kinda outdated piece of software please don&rsquo;t laugh), so I followed the instruction from this page https://docs.expressionengine.com/v3/installation/upgrade_from_2.x.html, check modules, permissions etc. and viewed the site at http://dev.local/system I got Exception Caught error</p>', 6, 1, 1, '2021-07-20 14:41:28', '2021-07-24 14:20:16'),
(6, 1, 'So I’m upgrading my old', 'so-im-upgrading-my-old', 'so-im-upgrading-my-old-60f7d740a8363.jpg', '<p>So I&rsquo;m upgrading my old site from 2.55 to the latest version (kinda outdated piece of software please don&rsquo;t laugh), so I followed the instruction from this page https://docs.expressionengine.com/v3/installation/upgrade_from_2.x.html, check modules, permissions etc.So I&rsquo;m upgrading my old site from 2.55 to the latest version (kinda outdated piece of software please don&rsquo;t laugh), so I followed the instruction from this page https://docs.expressionengine.com/v3/installation/upgrade_from_2.x.html, check modules, permissions etc.So I&rsquo;m upgrading my old site from 2.55 to the latest version (kinda outdated piece of software please don&rsquo;t laugh), so I followed the instruction from this page https://docs.expressionengine.com/v3/installation/upgrade_from_2.x.html, check modules, permissions etc.So I&rsquo;m upgrading my old site from 2.55 to the latest version (kinda outdated piece of software please don&rsquo;t laugh), so I followed the instruction from this page https://docs.expressionengine.com/v3/installation/upgrade_from_2.x.html, check modules, permissions etc.So I&rsquo;m upgrading my old site from 2.55 to the latest version (kinda outdated piece of software please don&rsquo;t laugh), so I followed the instruction from this page https://docs.expressionengine.com/v3/installation/upgrade_from_2.x.html, check modules, permissions etc.So I&rsquo;m upgrading my old site from 2.55 to the latest version (kinda outdated piece of software please don&rsquo;t laugh), so I followed the instruction from this page https://docs.expressionengine.com/v3/installation/upgrade_from_2.x.html, check modules, permissions etc.So I&rsquo;m upgrading my old site from 2.55 to the latest version (kinda outdated piece of software please don&rsquo;t laugh), so I followed the instruction from this page https://docs.expressionengine.com/v3/installation/upgrade_from_2.x.html, check modules, permissions etc.</p>', 3, 1, 1, '2021-07-21 02:13:53', '2021-07-24 11:43:55'),
(7, 2, 'This message upcoming was sent to rtjakemarak00', 'this-message-upcoming-was-sent-to-rtjakemarak00', 'this-message-upcoming-was-sent-to-rtjakemarak00-60fc65822ab8b.jpg', '<p>This message was sent to&nbsp;<a>rtjakemarak00@gmail.com</a>&nbsp;and intended for ekantaheen. Instagram sends updates like this to help you keep up with the latest on Instagram. You can unsubscribe from these updates, or remove your email if this isn\'t your Instagram account.&nbsp;<a href=\"https://instagram.com/emails/unsubscribe/reminders?user_id=5749250216&amp;sig=AU8yKdXyAKECQdYh\" target=\"_blank\" data-saferedirecturl=\"https://www.google.com/url?q=https://instagram.com/emails/unsubscribe/reminders?user_id%3D5749250216%26sig%3DAU8yKdXyAKECQdYh&amp;source=gmail&amp;ust=1627239059332000&amp;usg=AFQjCNE3zHPaJ34qJHG3ay0Q_qVMJIAC6Q\">Unsubscribe</a>&nbsp;or&nbsp;<a href=\"https://instagram.com/accounts/remove/revoke_wrong_email/?uidb36=2n2yduw&amp;token=5rj-536f930585f6e6809a6514e11d0e3030&amp;nonce=NRnvsVdI&amp;encoded_email=cnRqYWtlbWFyYWswMEBnbWFpbC5jb20\" target=\"_blank\" data-saferedirecturl=\"https://www.google.com/url?q=https://instagram.com/accounts/remove/revoke_wrong_email/?uidb36%3D2n2yduw%26token%3D5rj-536f930585f6e6809a6514e11d0e3030%26nonce%3DNRnvsVdI%26encoded_email%3DcnRqYWtlbWFyYWswMEBnbWFpbC5jb20&amp;source=gmail&amp;ust=1627239059332000&amp;usg=AFQjCNFCfd8fuifOxRMjWe8k88lCAGQ-kg\">rem</a>This message was sent to&nbsp;<a>rtjakemarak00@gmail.com</a>&nbsp;and intended for ekantaheen. Instagram sends updates like this to help you keep up with the latest on Instagram. You can unsubscribe from these updates, or remove your email if this isn\'t your Instagram account.&nbsp;<a href=\"https://instagram.com/emails/unsubscribe/reminders?user_id=5749250216&amp;sig=AU8yKdXyAKECQdYh\" target=\"_blank\" data-saferedirecturl=\"https://www.google.com/url?q=https://instagram.com/emails/unsubscribe/reminders?user_id%3D5749250216%26sig%3DAU8yKdXyAKECQdYh&amp;source=gmail&amp;ust=1627239059332000&amp;usg=AFQjCNE3zHPaJ34qJHG3ay0Q_qVMJIAC6Q\">Unsubscribe</a>&nbsp;or&nbsp;<a href=\"https://instagram.com/accounts/remove/revoke_wrong_email/?uidb36=2n2yduw&amp;token=5rj-536f930585f6e6809a6514e11d0e3030&amp;nonce=NRnvsVdI&amp;encoded_email=cnRqYWtlbWFyYWswMEBnbWFpbC5jb20\" target=\"_blank\" data-saferedirecturl=\"https://www.google.com/url?q=https://instagram.com/accounts/remove/revoke_wrong_email/?uidb36%3D2n2yduw%26token%3D5rj-536f930585f6e6809a6514e11d0e3030%26nonce%3DNRnvsVdI%26encoded_email%3DcnRqYWtlbWFyYWswMEBnbWFpbC5jb20&amp;source=gmail&amp;ust=1627239059332000&amp;usg=AFQjCNFCfd8fuifOxRMjWe8k88lCAGQ-kg\">rem</a>This message was sent to&nbsp;<a>rtjakemarak00@gmail.com</a>&nbsp;and intended for ekantaheen. Instagram sends updates like this to help you keep up with the latest on Instagram. You can unsubscribe from these updates, or remove your email if this isn\'t your Instagram account.&nbsp;<a href=\"https://instagram.com/emails/unsubscribe/reminders?user_id=5749250216&amp;sig=AU8yKdXyAKECQdYh\" target=\"_blank\" data-saferedirecturl=\"https://www.google.com/url?q=https://instagram.com/emails/unsubscribe/reminders?user_id%3D5749250216%26sig%3DAU8yKdXyAKECQdYh&amp;source=gmail&amp;ust=1627239059332000&amp;usg=AFQjCNE3zHPaJ34qJHG3ay0Q_qVMJIAC6Q\">Unsubscribe</a>&nbsp;or&nbsp;<a href=\"https://instagram.com/accounts/remove/revoke_wrong_email/?uidb36=2n2yduw&amp;token=5rj-536f930585f6e6809a6514e11d0e3030&amp;nonce=NRnvsVdI&amp;encoded_email=cnRqYWtlbWFyYWswMEBnbWFpbC5jb20\" target=\"_blank\" data-saferedirecturl=\"https://www.google.com/url?q=https://instagram.com/accounts/remove/revoke_wrong_email/?uidb36%3D2n2yduw%26token%3D5rj-536f930585f6e6809a6514e11d0e3030%26nonce%3DNRnvsVdI%26encoded_email%3DcnRqYWtlbWFyYWswMEBnbWFpbC5jb20&amp;source=gmail&amp;ust=1627239059332000&amp;usg=AFQjCNFCfd8fuifOxRMjWe8k88lCAGQ-kg\">rem</a>This message was sent to&nbsp;<a>rtjakemarak00@gmail.com</a>&nbsp;and intended for ekantaheen. Instagram sends updates like this to help you keep up with the latest on Instagram. You can unsubscribe from these updates, or remove your email if this isn\'t your Instagram account.&nbsp;<a href=\"https://instagram.com/emails/unsubscribe/reminders?user_id=5749250216&amp;sig=AU8yKdXyAKECQdYh\" target=\"_blank\" data-saferedirecturl=\"https://www.google.com/url?q=https://instagram.com/emails/unsubscribe/reminders?user_id%3D5749250216%26sig%3DAU8yKdXyAKECQdYh&amp;source=gmail&amp;ust=1627239059332000&amp;usg=AFQjCNE3zHPaJ34qJHG3ay0Q_qVMJIAC6Q\">Unsubscribe</a>&nbsp;or&nbsp;<a href=\"https://instagram.com/accounts/remove/revoke_wrong_email/?uidb36=2n2yduw&amp;token=5rj-536f930585f6e6809a6514e11d0e3030&amp;nonce=NRnvsVdI&amp;encoded_email=cnRqYWtlbWFyYWswMEBnbWFpbC5jb20\" target=\"_blank\" data-saferedirecturl=\"https://www.google.com/url?q=https://instagram.com/accounts/remove/revoke_wrong_email/?uidb36%3D2n2yduw%26token%3D5rj-536f930585f6e6809a6514e11d0e3030%26nonce%3DNRnvsVdI%26encoded_email%3DcnRqYWtlbWFyYWswMEBnbWFpbC5jb20&amp;source=gmail&amp;ust=1627239059332000&amp;usg=AFQjCNFCfd8fuifOxRMjWe8k88lCAGQ-kg\">rem</a></p>', 0, 0, 1, '2021-07-24 13:09:55', '2021-07-24 13:16:35'),
(8, 2, 'upcoming This message was sent to rtjakemarak00', 'upcoming-this-message-was-sent-to-rtjakemarak00', 'upcoming-this-message-was-sent-to-rtjakemarak00-60fc65ecec405.jpg', '<p>This message was sent to&nbsp;<a>rtjakemarak00</a>This message was sent to&nbsp;<a>rtjakemarak00&nbsp;as sent to&nbsp;</a><a>rtjakemarak00</a><a>This message was sent to&nbsp;</a><a>rtjakemarak00</a><a>as sent to&nbsp;</a><a>rtjakemarak00</a><a>This message was sent to&nbsp;</a><a>rtjakemarak00</a><a>as sent to&nbsp;</a><a>rtjakemarak00</a><a>This message was sent to&nbsp;</a><a>rtjakemarak00</a><a>as sent to&nbsp;</a><a>rtjakemarak00</a><a>This message was sent to&nbsp;</a><a>rtjakemarak00</a><a>as sent to&nbsp;</a><a>rtjakemarak00</a><a>This message was sent to&nbsp;</a><a>rtjakemarak00</a><a>as sent to&nbsp;</a><a>rtjakemarak00</a><a>This message was sent to&nbsp;</a><a>rtjakemarak00</a><a>as sent to&nbsp;</a><a>rtjakemarak00</a><a>This message was sent to&nbsp;</a><a>rtjakemarak00</a><a>as sent to&nbsp;</a><a>rtjakemarak00</a><a>This message was sent to&nbsp;</a><a>rtjakemarak00</a><a>as sent to&nbsp;</a><a>rtjakemarak00</a><a>This message was sent to&nbsp;</a><a>rtjakemarak00</a><a>as sent to&nbsp;</a><a>rtjakemarak00</a><a>This message was sent to&nbsp;</a><a>rtjakemarak00</a><a>as sent to&nbsp;</a><a>rtjakemarak00</a><a>This message was sent to&nbsp;</a><a>rtjakemarak00</a><a>as sent to&nbsp;</a><a>rtjakemarak00</a><a>This message was sent to&nbsp;</a><a>rtjakemarak00</a><a>as sent to&nbsp;</a><a>rtjakemarak00</a><a>This message was sent to&nbsp;</a><a>rtjakemarak00</a><a>as sent to&nbsp;</a><a>rtjakemarak00</a><a>This message was sent to&nbsp;</a><a>rtjakemarak00</a><a>as sent to&nbsp;</a><a>rtjakemarak00</a><a>This message was sent to&nbsp;</a><a>rtjakemarak00</a><a>as sent to&nbsp;</a><a>rtjakemarak00</a><a>This message was sent to&nbsp;</a><a>rtjakemarak00</a></p>', 1, 1, 1, '2021-07-24 13:11:41', '2021-07-26 13:09:22'),
(9, 5, 'authorrt this is authorrt posts', 'authorrt-this-is-authorrt-posts', 'authorrt-this-is-authorrt-posts-60ff068e76de9.jpg', '<p>In publishing and graphic design, Lorem ipsum is a placeholder text commonly used to demonstrate the visual form of a document or a typeface without relying on meaningful content.&nbsp;In publishing and graphic design, Lorem ipsum is a placeholder text commonly used to demonstrate the visual form of a document or a typeface without relying on meaningful content.&nbsp;In publishing and graphic design, Lorem ipsum is a placeholder text commonly used to demonstrate the visual form of a document or a typeface without relying on meaningful content.&nbsp;In publishing and graphic design, Lorem ipsum is a placeholder text commonly used to demonstrate the visual form of a document or a typeface without relying on meaningful content.&nbsp;In publishing and graphic design, Lorem ipsum is a placeholder text commonly used to demonstrate the visual form of a document or a typeface without relying on meaningful content.&nbsp;In publishing and graphic design, Lorem ipsum is a placeholder text commonly used to demonstrate the visual form of a document or a typeface without relying on meaningful content.&nbsp;In publishing and graphic design, Lorem ipsum is a placeholder text commonly used to demonstrate the visual form of a document or a typeface without relying on meaningful content.&nbsp;In publishing and graphic design, Lorem ipsum is a placeholder text commonly used to demonstrate the visual form of a document or a typeface without relying on meaningful content.&nbsp;In publishing and graphic design, Lorem ipsum is a placeholder text commonly used to demonstrate the visual form of a document or a typeface without relying on meaningful content.&nbsp;</p>', 0, 1, 1, '2021-07-26 13:01:35', '2021-07-26 13:04:25'),
(10, 5, 'Generator, Origins and Meaninghttps://loremipsum.io', 'generator-origins-and-meaninghttpsloremipsumio', 'generator-origins-and-meaninghttpsloremipsumio-60ff07021a674.jpg', '<p>publishing and graphic design, Lorem ipsum is a placeholder text commonly used to demonstrate the visual form of a document or a typeface without relying on meaningful content. Lorem ipsum may be used as a placeholder before final copy is availablpublishing and graphic design, Lorem ipsum is a placeholder text commonly used to demonstrate the visual form of a document or a typeface without relying on meaningful content. Lorem ipsum may be used as a placeholder before final copy is availabl</p>\r\n<p>publishing and graphic design, Lorem ipsum is a placeholder text commonly used to demonstrate the visual form of a document or a typeface without relying on meaningful content. Lorem ipsum may be used as a placeholder before final copy is availabl</p>\r\n<p>publishing and graphic design, Lorem ipsum is a placeholder text commonly used to demonstrate the visual form of a document or a typeface without relying on meaningful content. Lorem ipsum may be used as a placeholder before final copy is availabl</p>', 2, 1, 1, '2021-07-26 13:03:30', '2021-07-27 12:34:52'),
(11, 2, 'BANGKLADESH', 'bangkladesh', 'bangkladesh-61018cfa69beb.PNG', '<p>CVBHFZHDHFDH</p>', 0, 0, 0, '2021-07-28 10:59:40', '2021-07-28 10:59:40'),
(12, 1, 'bangla wiget', 'bangla-wiget', 'bangla-wiget-61058e21c74eb.jpg', '<p>dfhfduhjdfhfdh</p>', 0, 1, 1, '2021-07-31 11:53:39', '2021-07-31 11:53:39');

-- --------------------------------------------------------

--
-- Table structure for table `post_tag`
--

CREATE TABLE `post_tag` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `post_id` int(11) NOT NULL,
  `tag_id` int(11) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `post_tag`
--

INSERT INTO `post_tag` (`id`, `post_id`, `tag_id`, `created_at`, `updated_at`) VALUES
(1, 1, 1, '2021-07-19 15:12:48', '2021-07-19 15:12:48'),
(2, 2, 2, '2021-07-19 15:13:44', '2021-07-19 15:13:44'),
(3, 3, 3, '2021-07-19 15:14:21', '2021-07-19 15:14:21'),
(4, 4, 1, '2021-07-20 14:07:55', '2021-07-20 14:07:55'),
(5, 5, 1, '2021-07-20 14:41:28', '2021-07-20 14:41:28'),
(6, 6, 2, '2021-07-21 02:13:53', '2021-07-21 02:13:53'),
(7, 7, 3, '2021-07-24 13:09:55', '2021-07-24 13:09:55'),
(8, 8, 1, '2021-07-24 13:11:41', '2021-07-24 13:11:41'),
(9, 9, 1, '2021-07-26 13:01:35', '2021-07-26 13:01:35'),
(10, 10, 3, '2021-07-26 13:03:30', '2021-07-26 13:03:30'),
(11, 11, 1, '2021-07-28 10:59:40', '2021-07-28 10:59:40'),
(12, 12, 1, '2021-07-31 11:53:39', '2021-07-31 11:53:39');

-- --------------------------------------------------------

--
-- Table structure for table `post_user`
--

CREATE TABLE `post_user` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `post_id` bigint(20) UNSIGNED NOT NULL,
  `user_id` int(11) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `post_user`
--

INSERT INTO `post_user` (`id`, `post_id`, `user_id`, `created_at`, `updated_at`) VALUES
(1, 8, 2, '2021-07-28 11:36:19', '2021-07-28 11:36:19'),
(2, 4, 2, '2021-07-28 11:37:00', '2021-07-28 11:37:00'),
(3, 10, 2, '2021-07-28 11:37:33', '2021-07-28 11:37:33'),
(4, 6, 1, '2021-07-28 12:30:00', '2021-07-28 12:30:00');

-- --------------------------------------------------------

--
-- Table structure for table `roles`
--

CREATE TABLE `roles` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `slug` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `roles`
--

INSERT INTO `roles` (`id`, `name`, `slug`, `created_at`, `updated_at`) VALUES
(1, 'admin', 'admin', NULL, NULL),
(2, 'author', 'author', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `secondposts`
--

CREATE TABLE `secondposts` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `title` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `image` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'default.png',
  `body` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `secondposts`
--

INSERT INTO `secondposts` (`id`, `title`, `image`, `body`, `created_at`, `updated_at`) VALUES
(3, 'This is second title', 'this-is-second-title-61099bed5e4c3.PNG', '<p>Second post awesome font all it ike and share my font awesome fontike and share my font awesome fontike and share my font awesome font all it ike and share my font awesome fontike and share my font awesome fontike and share my font awesome font.lky</p>', '2021-08-03 13:41:34', '2021-08-03 13:44:03');

-- --------------------------------------------------------

--
-- Table structure for table `subscribers`
--

CREATE TABLE `subscribers` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `email` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `tags`
--

CREATE TABLE `tags` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `slug` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `tags`
--

INSERT INTO `tags` (`id`, `name`, `slug`, `created_at`, `updated_at`) VALUES
(1, 'html', 'html', '2021-07-19 15:09:55', '2021-07-19 15:09:55'),
(2, 'css', 'css', '2021-07-19 15:10:03', '2021-07-19 15:10:03'),
(3, 'wpordpress', 'wpordpress', '2021-07-19 15:10:15', '2021-07-19 15:10:15');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(10) UNSIGNED NOT NULL,
  `roleId` int(11) NOT NULL DEFAULT 2,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `UserName` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `password` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `image` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'default.pnp',
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `roleId`, `name`, `UserName`, `email`, `password`, `image`, `remember_token`, `created_at`, `updated_at`) VALUES
(1, 1, 'admin', 'admin', 'admin@gmail.com', '$2y$10$Rkpt8wncxYQFJSGliZDQ3OiIL2TKS2AzqEAkufjgYPlhc4IW9d9zu', 'admin-60f71d7c1bdc3.jpg', NULL, '2021-07-26 18:33:15', '2021-07-20 13:01:17'),
(2, 2, 'author', 'author', 'author@gmail.com', '$2y$10$n7Fzn35VNdwyxvUb9YQME.Ln6SLdPp5zXB7IIVKgypLEvunP4MbH2', 'author-60f72b318ba20.jpg', NULL, '2021-07-26 18:34:04', '2021-07-20 13:59:46'),
(5, 2, 'authorrt', 'authorrt', 'authorrt@gmail.com', '$2y$10$V/j3CmJncGRmX3dR6nxOX.nl5MhTKOy2aA3j9ni5HjLXZ/21SiKU6', 'authorrt-60ff06a5ba943.jpg', NULL, '2021-07-26 13:00:11', '2021-07-26 13:01:58');

-- --------------------------------------------------------

--
-- Table structure for table `widgets`
--

CREATE TABLE `widgets` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `title` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `image` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'default.png',
  `body` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `widgets`
--

INSERT INTO `widgets` (`id`, `title`, `image`, `body`, `created_at`, `updated_at`) VALUES
(1, 'Eloquent will also assume that each model\'s corresponding', 'this-is-my-widget-rantu-61084697bdccd.PNG', '<p>Eloquent will also assume that each model\'s corresponding database table has a primary key column named id. If necessary, you may define a protected $primaryKey property on your model to specify a different column that serves as your model\'s primary key:Eloquent will also assume that each model\'s corresponding</p>\r\n<p>Eloquent will also assume that each model\'s corresponding&nbsp;Eloquent will also assume that each model\'s corresponding&nbsp;Eloquent will also assume that each model\'s corresponding</p>\r\n<p>Eloquent will also assume that each model\'s corresponding</p>', NULL, '2021-08-04 13:03:00');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `categories`
--
ALTER TABLE `categories`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `category_post`
--
ALTER TABLE `category_post`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `comments`
--
ALTER TABLE `comments`
  ADD PRIMARY KEY (`id`),
  ADD KEY `comments_post_id_foreign` (`post_id`),
  ADD KEY `comments_user_id_foreign` (`user_id`);

--
-- Indexes for table `failed_jobs`
--
ALTER TABLE `failed_jobs`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `failed_jobs_uuid_unique` (`uuid`);

--
-- Indexes for table `jobs`
--
ALTER TABLE `jobs`
  ADD PRIMARY KEY (`id`),
  ADD KEY `jobs_queue_index` (`queue`);

--
-- Indexes for table `migrations`
--
ALTER TABLE `migrations`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `password_resets`
--
ALTER TABLE `password_resets`
  ADD KEY `password_resets_email_index` (`email`);

--
-- Indexes for table `posts`
--
ALTER TABLE `posts`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `posts_slug_unique` (`slug`),
  ADD KEY `posts_user_id_foreign` (`user_id`);

--
-- Indexes for table `post_tag`
--
ALTER TABLE `post_tag`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `post_user`
--
ALTER TABLE `post_user`
  ADD PRIMARY KEY (`id`),
  ADD KEY `post_user_post_id_foreign` (`post_id`);

--
-- Indexes for table `roles`
--
ALTER TABLE `roles`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `secondposts`
--
ALTER TABLE `secondposts`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `subscribers`
--
ALTER TABLE `subscribers`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tags`
--
ALTER TABLE `tags`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `users_username_unique` (`UserName`),
  ADD UNIQUE KEY `users_email_unique` (`email`);

--
-- Indexes for table `widgets`
--
ALTER TABLE `widgets`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `categories`
--
ALTER TABLE `categories`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `category_post`
--
ALTER TABLE `category_post`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;

--
-- AUTO_INCREMENT for table `comments`
--
ALTER TABLE `comments`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=19;

--
-- AUTO_INCREMENT for table `failed_jobs`
--
ALTER TABLE `failed_jobs`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `jobs`
--
ALTER TABLE `jobs`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;

--
-- AUTO_INCREMENT for table `migrations`
--
ALTER TABLE `migrations`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=18;

--
-- AUTO_INCREMENT for table `posts`
--
ALTER TABLE `posts`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;

--
-- AUTO_INCREMENT for table `post_tag`
--
ALTER TABLE `post_tag`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;

--
-- AUTO_INCREMENT for table `post_user`
--
ALTER TABLE `post_user`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `roles`
--
ALTER TABLE `roles`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `secondposts`
--
ALTER TABLE `secondposts`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `subscribers`
--
ALTER TABLE `subscribers`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `tags`
--
ALTER TABLE `tags`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `widgets`
--
ALTER TABLE `widgets`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `comments`
--
ALTER TABLE `comments`
  ADD CONSTRAINT `comments_post_id_foreign` FOREIGN KEY (`post_id`) REFERENCES `posts` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `comments_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `posts`
--
ALTER TABLE `posts`
  ADD CONSTRAINT `posts_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `post_user`
--
ALTER TABLE `post_user`
  ADD CONSTRAINT `post_user_post_id_foreign` FOREIGN KEY (`post_id`) REFERENCES `posts` (`id`) ON DELETE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
